const db = require('../config/firebase');

const isAdmin = async (req, res, next) => {
  try {
    const userDoc = await db.collection('users').doc(req.user.id).get();
    const user = userDoc.data();

    if (user?.role !== 'admin') {
      return res.status(403).json({ error: 'Access denied. Admins only.' });
    }

    next();
  } catch (error) {
    console.error('Admin check failed:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

module.exports = isAdmin;
