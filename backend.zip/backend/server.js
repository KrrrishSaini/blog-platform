console.log('Server file is running...');
const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
dotenv.config();
console.log('Environment variables loaded');
console.log('JWT_SECRET available:', !!process.env.JWT_SECRET);
console.log('PORT:', process.env.PORT);

// Declare routes before use
let authRoutes, blogRoutes;

function startServer() {
  console.log('Setting up Express app...');
  const app = express();

  app.use(cors({
    origin: function(origin, callback) {
      // Allow any origin that includes localhost
      if (!origin || origin.includes('localhost')) {
        callback(null, true);
      } else {
        callback(new Error('Not allowed by CORS'));
      }
    },
    credentials: true
  }));
  app.use(express.json());
  
  // Serve static files from uploads directory
  app.use('/uploads', express.static('uploads'));

  app.get('/health', (req, res) => {
    res.status(200).json({ status: 'ok', message: 'Server is running' });
  });

  if (authRoutes) {
    app.use('/api/auth', authRoutes);
    console.log('Auth routes mounted at /api/auth');
  } else {
    console.warn('Auth routes not loaded');
  }

  if (blogRoutes) {
    app.use('/api/blogs', blogRoutes);
    console.log('Blog routes mounted at /api/blogs');
  } else {
    console.warn('Blog routes not loaded');
  }

  const PORT = process.env.PORT || 5050;
  app.listen(PORT, () => {
    clearTimeout(timeout);
    console.log(`Server running on port ${PORT}`);
    console.log(`Health check: http://localhost:${PORT}/health`);
  });
}

// Timeout fallback
const timeout = setTimeout(() => {
  console.error('Startup timeout. Running with limited setup.');
  startServer();
}, 8000);

// Load routes
console.log('Loading routes...');
try {
  authRoutes = require('./routes/authRoutes');
  blogRoutes = require('./routes/blogRoutes');
  startServer();
} catch (error) {
  console.error('Route loading error:', error);
  startServer();
}