const express = require('express');
const {
  getAllBlogs,
  createBlog,
  updateBlog,
  deleteBlog,
  getUserBlogs,
  searchBlogs,
  likeBlog,
  unlikeBlog,
  addComment,
  getComments,
  getAnalytics,
  getBlogById,
  incrementView,
  bookmarkBlog,
  removeBookmark,
  getBookmarkedBlogs,
  checkBookmarkStatus
} = require('../controllers/blogController');

const authMiddleware = require('../middleware/authMiddleware');
const isAdmin = require('../middleware/isAdmin');
const upload = require('../middleware/upload');
const db = require('../config/firebase');

const router = express.Router();

// Blog Routes
router.get('/', getAllBlogs);
router.get('/user', authMiddleware, getUserBlogs);
router.get('/search', searchBlogs);
router.get('/bookmarks', authMiddleware, getBookmarkedBlogs); // Move this before /:id routes
router.post('/', authMiddleware, createBlog);
router.put('/:id', authMiddleware, updateBlog);
router.delete('/:id', authMiddleware, deleteBlog);
router.put('/:id/view', incrementView);
router.get('/:id', getBlogById);

// Likes
router.post('/:id/like', authMiddleware, likeBlog);
router.post('/:id/unlike', authMiddleware, unlikeBlog);

// Comments
router.post('/:id/comments', authMiddleware, addComment);
router.get('/:id/comments', getComments);

// Bookmarks
router.post('/:id/bookmark', authMiddleware, bookmarkBlog);
router.delete('/:id/bookmark', authMiddleware, removeBookmark);
router.get('/:id/bookmark-status', authMiddleware, checkBookmarkStatus);

// Analytics
router.get('/analytics', getAnalytics);

// ✅ Fixed Admin Stats with Firestore
router.get('/admin/stats', authMiddleware, isAdmin, async (req, res) => {
  try {
    const snapshot = await db.collection('blogs').get();
    const blogs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));

    const totalBlogs = blogs.length;
    const totalViews = blogs.reduce((sum, blog) => sum + (blog.views || 0), 0);
    const totalLikes = blogs.reduce((sum, blog) => sum + (blog.likes?.length || 0), 0);

    res.json({ totalBlogs, totalViews, totalLikes });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch stats' });
  }
});

module.exports = router;