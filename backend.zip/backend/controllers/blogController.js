const db = require('../config/firebase');

// Get all blogs
const getAllBlogs = async (req, res) => {
  try {
    const snapshot = await db.collection('blogs').orderBy('createdAt', 'desc').get();
    const blogs = await Promise.all(
      snapshot.docs.map(async (doc) => {
        const blogData = { id: doc.id, ...doc.data() };
        
        // Get comment count for each blog
        try {
          const commentsSnapshot = await db.collection('blogs')
            .doc(doc.id)
            .collection('comments')
            .get();
          
          blogData.commentCount = commentsSnapshot.size;
          blogData.comments = new Array(commentsSnapshot.size).fill(null); // For backward compatibility
        } catch (commentError) {
          console.error(`Error fetching comments for blog ${doc.id}:`, commentError);
          blogData.commentCount = 0;
          blogData.comments = [];
        }
        
        return blogData;
      })
    );
    
    // Sort by createdAt as fallback (in case orderBy didn't work)
    blogs.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    
    res.status(200).json(blogs);
  } catch (error) {
    console.error('Error fetching blogs:', error);
    res.status(500).json({ error: 'Failed to fetch blogs' });
  }
};

// Get blogs by logged-in user
const getUserBlogs = async (req, res) => {
  try {
    const userId = req.user.id;
    // Try with orderBy first, fallback to just where clause if composite index doesn't exist
    let snapshot;
    try {
      snapshot = await db.collection('blogs').where('userId', '==', userId).orderBy('createdAt', 'desc').get();
    } catch (error) {
      console.log('Composite index not available, using simple query:', error.message);
      snapshot = await db.collection('blogs').where('userId', '==', userId).get();
    }
    const blogs = await Promise.all(
      snapshot.docs.map(async (doc) => {
        const blogData = { id: doc.id, ...doc.data() };
        
        // Get comment count for each blog
        try {
          const commentsSnapshot = await db.collection('blogs')
            .doc(doc.id)
            .collection('comments')
            .get();
          
          blogData.commentCount = commentsSnapshot.size;
          blogData.comments = new Array(commentsSnapshot.size).fill(null); // For backward compatibility
        } catch (commentError) {
          console.error(`Error fetching comments for blog ${doc.id}:`, commentError);
          blogData.commentCount = 0;
          blogData.comments = [];
        }
        
        return blogData;
      })
    );
    
    // Sort by createdAt if not already sorted by database
    blogs.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    
    res.status(200).json(blogs);
  } catch (error) {
    console.error('Error fetching user blogs:', error);
    res.status(500).json({ error: 'Failed to fetch user blogs' });
  }
};

// Create a blog
const createBlog = async (req, res) => {
  try {
    console.log('Creating blog - Request body:', req.body);
    console.log('Creating blog - User:', req.user);
    
    const { title, content, imageBase64, tags } = req.body;

    // Validate required fields
    if (!title || !content) {
      return res.status(400).json({ 
        error: 'Title and content are required',
        received: { title: !!title, content: !!content }
      });
    }

    // Validate user object
    if (!req.user || !req.user.id) {
      return res.status(401).json({ 
        error: 'User authentication required',
        user: req.user 
      });
    }

    const blogData = {
      title,
      content,
      tags,
      imageBase64,
      author: req.user.name || req.user.email || 'Anonymous',
      userId: req.user.id,
      createdAt: new Date().toISOString(),
      likes: [],
      views: 0,
      commentCount: 0,
      comments: []
    };

    console.log('Blog data to be saved:', blogData);

    const docRef = await db.collection('blogs').add(blogData);
    const createdBlog = { id: docRef.id, ...blogData };
    
    console.log('Blog created successfully:', createdBlog);
    res.status(201).json(createdBlog);
  } catch (error) {
    console.error('Error creating blog:', error);
    res.status(500).json({ 
      error: 'Failed to create blog',
      details: error.message,
      stack: process.env.NODE_ENV === 'development' ? error.stack : undefined
    });
  }
};

// Update a blog
const updateBlog = async (req, res) => {
  try {
    const { id } = req.params;
    const updatedData = req.body;

    const blogRef = db.collection('blogs').doc(id);
    const blog = await blogRef.get();

    if (!blog.exists) {
      return res.status(404).json({ error: 'Blog not found' });
    }

    await blogRef.update(updatedData);
    res.status(200).json({ id, ...updatedData });
  } catch (error) {
    res.status(500).json({ error: 'Failed to update blog' });
  }
};

// Delete a blog
const deleteBlog = async (req, res) => {
  try {
    const { id } = req.params;
    await db.collection('blogs').doc(id).delete();
    res.status(200).json({ message: 'Blog deleted successfully', id });
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete blog' });
  }
};

// Search blogs
const searchBlogs = async (req, res) => {
  try {
    const query = req.query.q?.toLowerCase();
    if (!query) return res.status(400).json({ error: 'Missing search query' });

    const snapshot = await db.collection('blogs').get();
    const blogs = await Promise.all(
      snapshot.docs.map(async (doc) => {
        const blogData = { id: doc.id, ...doc.data() };
        
        // Get comment count for each blog
        try {
          const commentsSnapshot = await db.collection('blogs')
            .doc(doc.id)
            .collection('comments')
            .get();
          
          blogData.commentCount = commentsSnapshot.size;
          blogData.comments = new Array(commentsSnapshot.size).fill(null);
        } catch (commentError) {
          blogData.commentCount = 0;
          blogData.comments = [];
        }
        
        return blogData;
      })
    );

    const filteredBlogs = blogs.filter(blog =>
      blog.title.toLowerCase().includes(query) ||
      blog.content?.toLowerCase().includes(query) ||
      blog.author?.toLowerCase().includes(query) ||
      (blog.tags && blog.tags.some(tag => tag.toLowerCase().includes(query)))
    );

    res.status(200).json(filteredBlogs);
  } catch (error) {
    res.status(500).json({ error: 'Search failed' });
  }
};

// Add comment
const addComment = async (req, res) => {
  try {
    const { id } = req.params;
    const { content } = req.body;

    if (!content || !content.trim()) {
      return res.status(400).json({ error: 'Comment content is required' });
    }

    const comment = {
      content: content.trim(),
      author: req.user.name || req.user.email || 'Anonymous',
      user: {
        id: req.user.id,
        name: req.user.name || req.user.email || 'Anonymous'
      },
      userId: req.user.id,
      createdAt: new Date().toISOString()
    };

    const docRef = await db.collection('blogs').doc(id).collection('comments').add(comment);
    const createdComment = { id: docRef.id, ...comment };
    
    res.status(201).json(createdComment);
  } catch (error) {
    console.error('Error adding comment:', error);
    res.status(500).json({ error: 'Failed to add comment' });
  }
};

// Get comments
const getComments = async (req, res) => {
  try {
    const { id } = req.params;
    const snapshot = await db.collection('blogs')
      .doc(id)
      .collection('comments')
      .orderBy('createdAt', 'desc')
      .get();
    
    const comments = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    res.status(200).json(comments);
  } catch (error) {
    console.error('Error fetching comments:', error);
    res.status(500).json({ error: 'Failed to fetch comments' });
  }
};

// Like blog
const likeBlog = async (req, res) => {
  try {
    const { id } = req.params;
    const blogRef = db.collection('blogs').doc(id);
    const blog = await blogRef.get();

    if (!blog.exists) return res.status(404).json({ error: 'Blog not found' });

    const blogData = blog.data();
    const likes = blogData.likes || [];
    const userId = req.user.id;

    if (likes.includes(userId)) return res.status(400).json({ error: 'Already liked' });

    likes.push(userId);
    await blogRef.update({ likes });

    // Get comment count
    const commentsSnapshot = await db.collection('blogs').doc(id).collection('comments').get();
    const commentCount = commentsSnapshot.size;

    res.status(200).json({ 
      id, 
      ...blogData, 
      likes,
      commentCount,
      comments: new Array(commentCount).fill(null)
    });
  } catch (error) {
    res.status(500).json({ error: 'Failed to like blog' });
  }
};

// Unlike blog
const unlikeBlog = async (req, res) => {
  try {
    const { id } = req.params;
    const blogRef = db.collection('blogs').doc(id);
    const blog = await blogRef.get();

    if (!blog.exists) return res.status(404).json({ error: 'Blog not found' });

    const blogData = blog.data();
    const likes = blogData.likes || [];
    const userId = req.user.id;

    if (!likes.includes(userId)) return res.status(400).json({ error: 'You have not liked this blog' });

    const updatedLikes = likes.filter(uid => uid !== userId);
    await blogRef.update({ likes: updatedLikes });

    // Get comment count
    const commentsSnapshot = await db.collection('blogs').doc(id).collection('comments').get();
    const commentCount = commentsSnapshot.size;

    const updatedBlogData = { 
      ...blogData, 
      likes: updatedLikes,
      commentCount,
      comments: new Array(commentCount).fill(null)
    };
    res.status(200).json({ id, ...updatedBlogData });
  } catch (error) {
    res.status(500).json({ error: 'Failed to unlike blog' });
  }
};

// Get blog by ID
const getBlogById = async (req, res) => {
  try {
    const blogId = req.params.id;
    const blogDoc = await db.collection('blogs').doc(blogId).get();

    if (!blogDoc.exists) {
      return res.status(404).json({ message: 'Blog not found' });
    }

    res.status(200).json({ id: blogDoc.id, ...blogDoc.data() });
  } catch (error) {
    res.status(500).json({ message: 'Error retrieving blog', error: error.message });
  }
};

// Increment view count
const incrementView = async (req, res) => {
  try {
    const { id } = req.params;
    const blogRef = db.collection('blogs').doc(id);
    const blog = await blogRef.get();

    if (!blog.exists) {
      return res.status(404).json({ error: 'Blog not found' });
    }

    const blogData = blog.data();
    const currentViews = blogData.views || 0;
    const updatedViews = currentViews + 1;

    await blogRef.update({ views: updatedViews });

    // Get comment count
    const commentsSnapshot = await db.collection('blogs').doc(id).collection('comments').get();
    const commentCount = commentsSnapshot.size;

    const updatedBlogData = { 
      ...blogData, 
      views: updatedViews,
      commentCount,
      comments: new Array(commentCount).fill(null)
    };
    res.status(200).json({ id, ...updatedBlogData });
  } catch (error) {
    console.error('Error incrementing view count:', error);
    res.status(500).json({ error: 'Failed to increment view count' });
  }
};

// Get analytics
const getAnalytics = async (req, res) => {
  try {
    const blogSnap = await db.collection('blogs').get();
    const userSnap = await db.collection('users').get(); // Assuming you store users

    const totalBlogs = blogSnap.size;
    const totalUsers = userSnap.size;

    res.status(200).json({ totalBlogs, totalUsers });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch analytics data' });
  }
};

// Bookmark blog
const bookmarkBlog = async (req, res) => {
  try {
    const { id } = req.params;
    const userId = req.user.id;

    // Check if blog exists
    const blogRef = db.collection('blogs').doc(id);
    const blog = await blogRef.get();

    if (!blog.exists) {
      return res.status(404).json({ error: 'Blog not found' });
    }

    // Add bookmark to user's bookmarks collection
    const bookmarkRef = db.collection('users').doc(userId).collection('bookmarks').doc(id);
    const existingBookmark = await bookmarkRef.get();

    if (existingBookmark.exists) {
      return res.status(400).json({ error: 'Blog already bookmarked' });
    }

    await bookmarkRef.set({
      blogId: id,
      createdAt: new Date().toISOString()
    });

    res.status(200).json({ message: 'Blog bookmarked successfully' });
  } catch (error) {
    console.error('Error bookmarking blog:', error);
    res.status(500).json({ error: 'Failed to bookmark blog' });
  }
};

// Remove bookmark
const removeBookmark = async (req, res) => {
  try {
    const { id } = req.params;
    const userId = req.user.id;

    const bookmarkRef = db.collection('users').doc(userId).collection('bookmarks').doc(id);
    const bookmark = await bookmarkRef.get();

    if (!bookmark.exists) {
      return res.status(400).json({ error: 'Blog not bookmarked' });
    }

    await bookmarkRef.delete();
    res.status(200).json({ message: 'Bookmark removed successfully' });
  } catch (error) {
    console.error('Error removing bookmark:', error);
    res.status(500).json({ error: 'Failed to remove bookmark' });
  }
};

// Get user's bookmarked blogs
const getBookmarkedBlogs = async (req, res) => {
  try {
    const userId = req.user.id;

    // Get user's bookmarks
    const bookmarksSnapshot = await db.collection('users')
      .doc(userId)
      .collection('bookmarks')
      .orderBy('createdAt', 'desc')
      .get();

    if (bookmarksSnapshot.empty) {
      return res.status(200).json([]);
    }

    // Get the actual blog data for each bookmark
    const bookmarkedBlogs = await Promise.all(
      bookmarksSnapshot.docs.map(async (bookmarkDoc) => {
        const blogId = bookmarkDoc.data().blogId;
        const blogDoc = await db.collection('blogs').doc(blogId).get();
        
        if (blogDoc.exists) {
          const blogData = { id: blogDoc.id, ...blogDoc.data() };
          
          // Get comment count
          try {
            const commentsSnapshot = await db.collection('blogs')
              .doc(blogId)
              .collection('comments')
              .get();
            
            blogData.commentCount = commentsSnapshot.size;
            blogData.comments = new Array(commentsSnapshot.size).fill(null);
          } catch (commentError) {
            blogData.commentCount = 0;
            blogData.comments = [];
          }
          
          return blogData;
        }
        return null;
      })
    );

    // Filter out null values (deleted blogs)
    const validBookmarks = bookmarkedBlogs.filter(blog => blog !== null);
    res.status(200).json(validBookmarks);
  } catch (error) {
    console.error('Error fetching bookmarked blogs:', error);
    res.status(500).json({ error: 'Failed to fetch bookmarked blogs' });
  }
};

// Check if blog is bookmarked by user
const checkBookmarkStatus = async (req, res) => {
  try {
    const { id } = req.params;
    const userId = req.user.id;

    const bookmarkRef = db.collection('users').doc(userId).collection('bookmarks').doc(id);
    const bookmark = await bookmarkRef.get();

    res.status(200).json({ isBookmarked: bookmark.exists });
  } catch (error) {
    console.error('Error checking bookmark status:', error);
    res.status(500).json({ error: 'Failed to check bookmark status' });
  }
};

module.exports = {
  getAllBlogs,
  getUserBlogs,
  createBlog,
  updateBlog,
  deleteBlog,
  searchBlogs,
  addComment,
  getComments,
  likeBlog,
  unlikeBlog,
  getAnalytics,
  getBlogById,
  incrementView,
  bookmarkBlog,
  removeBookmark,
  getBookmarkedBlogs,
  checkBookmarkStatus
};