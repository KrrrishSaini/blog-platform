const db = require('../config/firebase');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

// Register a new user
const registerUser = async (req, res) => {
  try {
    const { name, email, password, role = 'user' } = req.body;

    // Check if user already exists
    const userSnap = await db.collection('users').where('email', '==', email).get();
    if (!userSnap.empty) {
      return res.status(400).json({ error: 'User already exists' });
    }

    // Hash the password
    const hashedPassword = await bcrypt.hash(password, 10);

    const userData = {
      name,
      email,
      password: hashedPassword,
      role, // 'user' or 'admin'
      bio: '', // Default empty bio
      profilePicture: '', // Default empty profile picture
      createdAt: new Date().toISOString()
    };

    const newUserRef = await db.collection('users').add(userData);
    
    // Generate JWT token for the new user
    const token = jwt.sign(
      {
        id: newUserRef.id,
        name: userData.name,
        email: userData.email,
        role: userData.role
      },
      process.env.JWT_SECRET,
      { expiresIn: '2d' }
    );

    res.status(201).json({ 
      id: newUserRef.id, 
      name: userData.name,
      email: userData.email,
      role: userData.role,
      token,
      createdAt: userData.createdAt
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Registration failed' });
  }
};

// Login user
const loginUser = async (req, res) => {
  try {
    const { email, password } = req.body;

    // Find user by email
    const userSnap = await db.collection('users').where('email', '==', email).get();
    if (userSnap.empty) {
      return res.status(404).json({ error: 'User not found' });
    }

    const userDoc = userSnap.docs[0];
    const user = userDoc.data();

    // Compare password
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    // Generate JWT token
    const token = jwt.sign(
      {
        id: userDoc.id,
        name: user.name,
        email: user.email,
        role: user.role
      },
      process.env.JWT_SECRET,
      { expiresIn: '2d' }
    );

    // Return user data with token (exclude password)
    res.status(200).json({
      id: userDoc.id,
      name: user.name,
      email: user.email,
      role: user.role,
      token,
      createdAt: user.createdAt
    });
  } catch (error) {
    console.error(error); // Debug info
    res.status(500).json({ error: 'Login failed' });
  }
};

// Add this function in your authController.js

const getUserProfile = async (req, res) => {
  try {
    const userId = req.user.id;
    const userDoc = await db.collection('users').doc(userId).get();

    if (!userDoc.exists) return res.status(404).json({ error: 'User not found' });

    const user = userDoc.data();
    delete user.password;

    res.status(200).json({ id: userId, ...user });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch user profile' });
  }
};

// Update user profile
const updateProfile = async (req, res) => {
  try {
    const userId = req.user.id;
    const { name, bio, profilePicture } = req.body;

    // Validate required fields
    if (!name || name.trim() === '') {
      return res.status(400).json({ error: 'Name is required' });
    }

    // Prepare update data
    const updateData = {
      name: name.trim(),
      bio: bio ? bio.trim() : '',
      profilePicture: profilePicture || '',
      updatedAt: new Date().toISOString()
    };

    // Update user in database
    await db.collection('users').doc(userId).update(updateData);

    // Get updated user data
    const userDoc = await db.collection('users').doc(userId).get();
    const user = userDoc.data();
    delete user.password;

    res.status(200).json({
      id: userId,
      ...user,
      message: 'Profile updated successfully'
    });
  } catch (error) {
    console.error('Update profile error:', error);
    res.status(500).json({ error: 'Failed to update profile' });
  }
};

module.exports = {
  registerUser,
  loginUser,
  getUserProfile,
  updateProfile
};