class Blog {
  final String id;
  final String title;
  final String content;
  final String author;
  final String userId;
  final String createdAt;
  final List<String> likes;
  final int views;
  final List<String> tags;
  final String? imageBase64;
  final int commentCount;

  Blog({
    required this.id,
    required this.title,
    required this.content,
    required this.author,
    required this.userId,
    required this.createdAt,
    required this.likes,
    required this.views,
    required this.tags,
    this.imageBase64,
    required this.commentCount,
  });

  factory Blog.fromJson(Map<String, dynamic> json) {
    return Blog(
      id: json['id'] ?? '',
      title: json['title'] ?? '',
      content: json['content'] ?? '',
      author: json['author'] ?? '',
      userId: json['userId'] ?? '',
      createdAt: json['createdAt'] ?? '',
      likes: List<String>.from(json['likes'] ?? []),
      views: json['views'] ?? 0,
      tags: List<String>.from(json['tags'] ?? []),
      imageBase64: json['imageBase64'],
      commentCount: json['commentCount'] ?? 0,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'content': content,
      'author': author,
      'userId': userId,
      'createdAt': createdAt,
      'likes': likes,
      'views': views,
      'tags': tags,
      'imageBase64': imageBase64,
      'commentCount': commentCount,
    };
  }
}