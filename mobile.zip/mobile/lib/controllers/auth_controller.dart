import 'dart:convert';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/user.dart';
import '../services/api_service.dart';

class AuthController extends GetxController {
  var isLoggedIn = false.obs;
  var isLoading = false.obs;
  Rx<User?> currentUser = Rx<User?>(null);

  @override
  void onInit() {
    super.onInit();
    checkLoginStatus();
  }

  Future<void> checkLoginStatus() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? token = prefs.getString('token');
    String? userData = prefs.getString('user');
    
    if (token != null && userData != null) {
      try {
        Map<String, dynamic> userMap = jsonDecode(userData);
        currentUser.value = User.fromJson(userMap);
        isLoggedIn.value = true;
      } catch (e) {
        print('Error parsing user data: $e');
      }
    }
  }

  Future<bool> login(String email, String password) async {
    try {
      isLoading.value = true;
      
      final response = await ApiService.login(email, password);
      
      if (response != null && response['token'] != null) {
        // Save user data
        SharedPreferences prefs = await SharedPreferences.getInstance();
        await prefs.setString('token', response['token']);
        
        // Create user object directly from response
        final userData = {
          'id': response['id'] ?? '',
          'name': response['name'] ?? '',
          'email': response['email'] ?? '',
          'token': response['token'] ?? '',
        };
        
        await prefs.setString('user', jsonEncode(userData));
        
        currentUser.value = User.fromJson(userData);
        isLoggedIn.value = true;
        
        Get.offAllNamed('/home');
        return true;
      }
      Get.snackbar('Login Failed', 'Invalid credentials or server error');
      return false;
    } catch (e) {
      print('Login error in controller: $e');
      Get.snackbar('Error', e.toString().replaceAll('Exception: ', ''));
      return false;
    } finally {
      isLoading.value = false;
    }
  }

  Future<bool> register(String name, String email, String password) async {
    try {
      isLoading.value = true;
      
      final response = await ApiService.register(name, email, password);
      
      if (response != null && response['token'] != null) {
        // Save user data
        SharedPreferences prefs = await SharedPreferences.getInstance();
        await prefs.setString('token', response['token']);
        
        // Create user object directly from response
        final userData = {
          'id': response['id'] ?? '',
          'name': response['name'] ?? '',
          'email': response['email'] ?? '',
          'token': response['token'] ?? '',
        };
        
        await prefs.setString('user', jsonEncode(userData));
        
        currentUser.value = User.fromJson(userData);
        isLoggedIn.value = true;
        
        Get.offAllNamed('/home');
        return true;
      }
      Get.snackbar('Registration Failed', 'Could not create account');
      return false;
    } catch (e) {
      print('Register error in controller: $e');
      Get.snackbar('Error', e.toString().replaceAll('Exception: ', ''));
      return false;
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> logout() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    
    currentUser.value = null;
    isLoggedIn.value = false;
    
    Get.offAllNamed('/login');
  }

  String? get token => currentUser.value?.token;
}