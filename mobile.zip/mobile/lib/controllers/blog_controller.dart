import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/blog.dart';
import '../services/api_service.dart';
import '../services/comment_service.dart';
import 'auth_controller.dart';

class BlogController extends GetxController {
  var blogs = <Blog>[].obs;
  var userBlogs = <Blog>[].obs;
  var bookmarkedBlogs = <String>[].obs; // List of bookmarked blog IDs
  var isLoading = false.obs;
  var selectedBlog = Rx<Blog?>(null);

  final AuthController authController = Get.find<AuthController>();

  @override
  void onInit() {
    super.onInit();
    fetchAllBlogs();
    loadBookmarks();
  }
  
  Future<void> loadBookmarks() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final bookmarksJson = prefs.getStringList('bookmarks') ?? [];
      bookmarkedBlogs.clear();
      bookmarkedBlogs.addAll(bookmarksJson);
      update();
    } catch (e) {
      print('Error loading bookmarks: $e');
    }
  }
  
  Future<void> saveBookmarks() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setStringList('bookmarks', bookmarkedBlogs.toList());
    } catch (e) {
      print('Error saving bookmarks: $e');
    }
  }

  Future<void> fetchAllBlogs() async {
    try {
      isLoading.value = true;
      blogs.value = await ApiService.getAllBlogs();
    } catch (e) {
      Get.snackbar('Error', 'Failed to fetch blogs: $e');
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> fetchUserBlogs() async {
    try {
      isLoading.value = true;
      if (authController.token != null) {
        userBlogs.value = await ApiService.getUserBlogs(authController.token!);
      }
    } catch (e) {
      Get.snackbar('Error', 'Failed to fetch user blogs: $e');
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> fetchBlogById(String id) async {
    try {
      isLoading.value = true;
      selectedBlog.value = await ApiService.getBlogById(id);
      // Increment view count locally
      if (selectedBlog.value != null) {
        incrementBlogViews(id);
      }
    } catch (e) {
      Get.snackbar('Error', 'Failed to fetch blog: $e');
    } finally {
      isLoading.value = false;
    }
  }
  
  void incrementBlogViews(String id) {
    try {
      // Update in blogs list
      int blogIndex = blogs.indexWhere((blog) => blog.id == id);
      if (blogIndex != -1) {
        int newViews = blogs[blogIndex].views + 1;
        blogs[blogIndex] = Blog(
          id: blogs[blogIndex].id,
          title: blogs[blogIndex].title,
          content: blogs[blogIndex].content,
          author: blogs[blogIndex].author,
          userId: blogs[blogIndex].userId,
          createdAt: blogs[blogIndex].createdAt,
          likes: blogs[blogIndex].likes,
          views: newViews,
          tags: blogs[blogIndex].tags,
          imageBase64: blogs[blogIndex].imageBase64,
          commentCount: blogs[blogIndex].commentCount,
        );
      }

      // Update selected blog if it's the same
      if (selectedBlog.value != null && selectedBlog.value?.id == id) {
        int newViews = selectedBlog.value!.views + 1;
        selectedBlog.value = Blog(
          id: selectedBlog.value!.id,
          title: selectedBlog.value!.title,
          content: selectedBlog.value!.content,
          author: selectedBlog.value!.author,
          userId: selectedBlog.value!.userId,
          createdAt: selectedBlog.value!.createdAt,
          likes: selectedBlog.value!.likes,
          views: newViews,
          tags: selectedBlog.value!.tags,
          imageBase64: selectedBlog.value!.imageBase64,
          commentCount: selectedBlog.value!.commentCount,
        );
      }
      
      // In a real app, you would also update the view count on the server
      if (authController.token != null) {
        try {
          ApiService.incrementBlogViews(id);
        } catch (e) {
          print('Error updating view count on server: $e');
        }
      }
    } catch (e) {
      print('Error incrementing blog views: $e');
    }
  }

  Future<bool> createBlog(Map<String, dynamic> blogData) async {
    try {
      isLoading.value = true;
      if (authController.token != null) {
        Blog newBlog = await ApiService.createBlog(authController.token!, blogData);
        blogs.insert(0, newBlog);
        userBlogs.insert(0, newBlog);
        Get.back();
        Get.snackbar('Success', 'Blog created successfully!');
        return true;
      }
      return false;
    } catch (e) {
      Get.snackbar('Error', 'Failed to create blog: $e');
      return false;
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> deleteBlog(String id) async {
    try {
      if (authController.token != null) {
        await ApiService.deleteBlog(authController.token!, id);
        blogs.removeWhere((blog) => blog.id == id);
        userBlogs.removeWhere((blog) => blog.id == id);
        Get.snackbar('Success', 'Blog deleted successfully!');
      }
    } catch (e) {
      Get.snackbar('Error', 'Failed to delete blog: $e');
    }
  }

  Future<void> likeBlog(String id) async {
    try {
      if (authController.token != null) {
        try {
          await ApiService.likeBlog(authController.token!, id);
        } catch (e) {
          print('API error when liking blog: $e');
          // Continue with local update even if API fails
        }
        // Update local data
        _updateBlogLike(id, true);
      } else {
        Get.snackbar('Authentication Required', 'Please login to like blogs');
      }
    } catch (e) {
      print('Error in likeBlog: $e');
      Get.snackbar('Error', 'Failed to like blog');
    }
  }

  Future<void> unlikeBlog(String id) async {
    try {
      if (authController.token != null) {
        try {
          await ApiService.unlikeBlog(authController.token!, id);
        } catch (e) {
          print('API error when unliking blog: $e');
          // Continue with local update even if API fails
        }
        // Update local data
        _updateBlogLike(id, false);
      } else {
        Get.snackbar('Authentication Required', 'Please login to unlike blogs');
      }
    } catch (e) {
      print('Error in unlikeBlog: $e');
      Get.snackbar('Error', 'Failed to unlike blog');
    }
  }

  void _updateBlogLike(String id, bool isLiked) {
    try {
      String userId = authController.currentUser.value?.id ?? '';
      if (userId.isEmpty) {
        print('Cannot update like: User ID is empty');
        return;
      }
      
      // Update in blogs list
      int blogIndex = blogs.indexWhere((blog) => blog.id == id);
      if (blogIndex != -1) {
        List<String> likes = List.from(blogs[blogIndex].likes);
        if (isLiked && !likes.contains(userId)) {
          likes.add(userId);
        } else if (!isLiked && likes.contains(userId)) {
          likes.remove(userId);
        }
        blogs[blogIndex] = Blog(
          id: blogs[blogIndex].id,
          title: blogs[blogIndex].title,
          content: blogs[blogIndex].content,
          author: blogs[blogIndex].author,
          userId: blogs[blogIndex].userId,
          createdAt: blogs[blogIndex].createdAt,
          likes: likes,
          views: blogs[blogIndex].views,
          tags: blogs[blogIndex].tags,
          imageBase64: blogs[blogIndex].imageBase64,
          commentCount: blogs[blogIndex].commentCount,
        );
      }

      // Update selected blog if it's the same
      if (selectedBlog.value != null && selectedBlog.value?.id == id) {
        List<String> likes = List.from(selectedBlog.value!.likes);
        if (isLiked && !likes.contains(userId)) {
          likes.add(userId);
        } else if (!isLiked && likes.contains(userId)) {
          likes.remove(userId);
        }
        selectedBlog.value = Blog(
          id: selectedBlog.value!.id,
          title: selectedBlog.value!.title,
          content: selectedBlog.value!.content,
          author: selectedBlog.value!.author,
          userId: selectedBlog.value!.userId,
          createdAt: selectedBlog.value!.createdAt,
          likes: likes,
          views: selectedBlog.value!.views,
          tags: selectedBlog.value!.tags,
          imageBase64: selectedBlog.value!.imageBase64,
          commentCount: selectedBlog.value!.commentCount,
        );
      }
    } catch (e) {
      print('Error updating blog like: $e');
    }
  }

  bool isLikedByUser(Blog blog) {
    if (authController.currentUser.value == null) return false;
    String userId = authController.currentUser.value?.id ?? '';
    return userId.isNotEmpty && blog.likes.contains(userId);
  }
  
  bool isBookmarked(String blogId) {
    return bookmarkedBlogs.contains(blogId);
  }
  
  Future<int> getCommentCount(String blogId) async {
    try {
      final commentService = CommentService();
      return await commentService.getCommentCount(blogId);
    } catch (e) {
      print('Error getting comment count: $e');
      return 0;
    }
  }
  
  Future<void> updateCommentCount(String blogId, int count) async {
    try {
      // Update in blogs list
      int blogIndex = blogs.indexWhere((blog) => blog.id == blogId);
      if (blogIndex != -1) {
        blogs[blogIndex] = Blog(
          id: blogs[blogIndex].id,
          title: blogs[blogIndex].title,
          content: blogs[blogIndex].content,
          author: blogs[blogIndex].author,
          userId: blogs[blogIndex].userId,
          createdAt: blogs[blogIndex].createdAt,
          likes: blogs[blogIndex].likes,
          views: blogs[blogIndex].views,
          tags: blogs[blogIndex].tags,
          imageBase64: blogs[blogIndex].imageBase64,
          commentCount: count,
        );
      }

      // Update selected blog if it's the same
      if (selectedBlog.value != null && selectedBlog.value?.id == blogId) {
        selectedBlog.value = Blog(
          id: selectedBlog.value!.id,
          title: selectedBlog.value!.title,
          content: selectedBlog.value!.content,
          author: selectedBlog.value!.author,
          userId: selectedBlog.value!.userId,
          createdAt: selectedBlog.value!.createdAt,
          likes: selectedBlog.value!.likes,
          views: selectedBlog.value!.views,
          tags: selectedBlog.value!.tags,
          imageBase64: selectedBlog.value!.imageBase64,
          commentCount: count,
        );
      }
    } catch (e) {
      print('Error updating comment count: $e');
    }
  }
  
  void toggleBookmark(Blog blog) {
    if (bookmarkedBlogs.contains(blog.id)) {
      bookmarkedBlogs.remove(blog.id);
      Get.snackbar('Bookmark Removed', 'Blog removed from bookmarks');
    } else {
      bookmarkedBlogs.add(blog.id);
      Get.snackbar('Bookmarked', 'Blog added to bookmarks');
    }
    
    // Save bookmarks to shared preferences
    saveBookmarks();
    update(); // Force UI update
  }
  
  void toggleLike(Blog blog) {
    if (authController.currentUser.value == null) {
      Get.snackbar('Authentication Required', 'Please login to like blogs');
      return;
    }
    
    String userId = authController.currentUser.value!.id;
    bool isCurrentlyLiked = blog.likes.contains(userId);
    
    if (isCurrentlyLiked) {
      unlikeBlog(blog.id);
    } else {
      likeBlog(blog.id);
    }
  }
  
  void setSelectedBlogAndLoadComments(Blog blog) {
    selectedBlog.value = blog;
    // Update comment count
    getCommentCount(blog.id).then((count) {
      if (count > 0) {
        updateCommentCount(blog.id, count);
      }
    });
  }
}