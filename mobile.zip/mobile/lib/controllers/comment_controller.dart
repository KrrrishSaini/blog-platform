import 'dart:convert';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/comment.dart';
import 'auth_controller.dart';

class CommentController extends GetxController {
  final AuthController authController = Get.find<AuthController>();
  
  // Current blog comments
  final RxList<Comment> comments = <Comment>[].obs;
  
  // Current blog ID
  String currentBlogId = '';
  
  // Load comments for a blog
  Future<void> loadComments(String blogId) async {
    if (blogId.isEmpty) return;
    
    currentBlogId = blogId;
    
    try {
      final prefs = await SharedPreferences.getInstance();
      final commentsJson = prefs.getStringList('comments_$blogId') ?? [];
      
      List<Comment> loadedComments = commentsJson.map((jsonStr) {
        Map<String, dynamic> json = jsonDecode(jsonStr);
        return Comment.fromJson(json);
      }).toList();
      
      comments.value = loadedComments;
      update();
    } catch (e) {
      print('Error loading comments: $e');
    }
  }
  
  // Add a comment
  Future<void> addComment(String content) async {
    if (content.trim().isEmpty || 
        authController.currentUser.value == null ||
        currentBlogId.isEmpty) {
      return;
    }
    
    try {
      Comment newComment = Comment(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        userId: authController.currentUser.value?.id ?? 'unknown',
        username: authController.currentUser.value?.name ?? 'Anonymous',
        content: content.trim(),
        createdAt: DateTime.now().toIso8601String(),
      );
      
      List<Comment> updatedComments = List<Comment>.from(comments);
      updatedComments.add(newComment);
      comments.value = updatedComments;
      
      await saveComments();
      
      Get.snackbar('Comment Posted', 'Your comment has been added');
      update();
    } catch (e) {
      print('Error adding comment: $e');
    }
  }
  
  // Save comments
  Future<void> saveComments() async {
    if (currentBlogId.isEmpty) return;
    
    try {
      final prefs = await SharedPreferences.getInstance();
      List<String> commentsJson = comments.map((comment) {
        return jsonEncode(comment.toJson());
      }).toList();
      
      await prefs.setStringList('comments_$currentBlogId', commentsJson);
    } catch (e) {
      print('Error saving comments: $e');
    }
  }
  
  // Get comment count for a blog
  Future<int> getCommentCount(String blogId) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final commentsJson = prefs.getStringList('comments_$blogId') ?? [];
      return commentsJson.length;
    } catch (e) {
      print('Error getting comment count: $e');
      return 0;
    }
  }
}