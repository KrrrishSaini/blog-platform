import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../controllers/auth_controller.dart';
import '../../controllers/blog_controller.dart';
import '../../models/blog.dart';
import '../blog/blog_detail_screen.dart';

class HomeScreen extends StatelessWidget {
  final AuthController authController = Get.find<AuthController>();
  final BlogController blogController = Get.put(BlogController());

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          title: Text(
            'Blog Platform',
            style: TextStyle(
              fontWeight: FontWeight.bold,
              letterSpacing: 0.5,
            ),
          ),
          backgroundColor: Colors.indigo,
          foregroundColor: Colors.white,
          elevation: 0,
          actions: [
            Obx(() => CircleAvatar(
              backgroundColor: Colors.indigo[300],
              radius: 16,
              child: Text(
                authController.currentUser.value?.name.isNotEmpty == true
                    ? authController.currentUser.value!.name[0].toUpperCase()
                    : 'A',
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 14,
                ),
              ),
            )),
            SizedBox(width: 8),
            IconButton(
              icon: Icon(Icons.logout),
              onPressed: () => authController.logout(),
              tooltip: 'Logout',
            ),
          ],
          bottom: TabBar(
            labelColor: Colors.white,
            unselectedLabelColor: Colors.white.withOpacity(0.7),
            indicatorColor: Colors.white,
            indicatorWeight: 3,
            labelStyle: TextStyle(fontWeight: FontWeight.bold),
            tabs: [
              Tab(icon: Icon(Icons.home), text: 'All Blogs'),
              Tab(icon: Icon(Icons.person), text: 'My Blogs'),
              Tab(icon: Icon(Icons.bookmark), text: 'Bookmarks'),
            ],
          ),
        ),
        body: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [Colors.indigo.withOpacity(0.1), Colors.white],
              stops: [0.0, 0.3],
            ),
          ),
          child: TabBarView(
            children: [
              _buildAllBlogsTab(),
              _buildMyBlogsTab(),
              _buildBookmarksTab(),
            ],
          ),
        ),
        floatingActionButton: FloatingActionButton.extended(
          onPressed: () => Get.toNamed('/create-blog'),
          backgroundColor: Colors.indigo,
          icon: Icon(Icons.add, color: Colors.white),
          label: Text('New Blog', style: TextStyle(color: Colors.white)),
          elevation: 4,
        ),
      ),
    );
  }

  Widget _buildAllBlogsTab() {
    return Obx(() {
      if (blogController.isLoading.value && blogController.blogs.isEmpty) {
        return Center(
          child: CircularProgressIndicator(
            valueColor: AlwaysStoppedAnimation<Color>(Colors.indigo),
          ),
        );
      }

      if (blogController.blogs.isEmpty) {
        return Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.article_outlined, size: 80, color: Colors.grey[400]),
              SizedBox(height: 24),
              Text(
                'No blogs available',
                style: TextStyle(
                  fontSize: 20, 
                  color: Colors.grey[600],
                  fontWeight: FontWeight.w500,
                ),
              ),
              SizedBox(height: 16),
              ElevatedButton.icon(
                onPressed: () => Get.toNamed('/create-blog'),
                icon: Icon(Icons.add),
                label: Text('Create Your First Blog'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.indigo,
                  foregroundColor: Colors.white,
                  padding: EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                ),
              ),
            ],
          ),
        );
      }

      return RefreshIndicator(
        onRefresh: () => blogController.fetchAllBlogs(),
        color: Colors.indigo,
        child: ListView.builder(
          padding: EdgeInsets.all(16),
          itemCount: blogController.blogs.length,
          itemBuilder: (context, index) {
            return _buildBlogCard(blogController.blogs[index]);
          },
        ),
      );
    });
  }

  Widget _buildMyBlogsTab() {
    // Fetch user blogs when tab is opened
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (blogController.userBlogs.isEmpty) {
        blogController.fetchUserBlogs();
      }
    });

    return Obx(() {
      if (blogController.isLoading.value && blogController.userBlogs.isEmpty) {
        return Center(
          child: CircularProgressIndicator(
            valueColor: AlwaysStoppedAnimation<Color>(Colors.indigo),
          ),
        );
      }

      if (blogController.userBlogs.isEmpty) {
        return Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.person_outline, size: 80, color: Colors.grey[400]),
              SizedBox(height: 24),
              Text(
                'You haven\'t created any blogs yet',
                style: TextStyle(
                  fontSize: 20, 
                  color: Colors.grey[600],
                  fontWeight: FontWeight.w500,
                ),
              ),
              SizedBox(height: 16),
              ElevatedButton.icon(
                onPressed: () => Get.toNamed('/create-blog'),
                icon: Icon(Icons.add),
                label: Text('Create Your First Blog'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.indigo,
                  foregroundColor: Colors.white,
                  padding: EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                ),
              ),
            ],
          ),
        );
      }

      return RefreshIndicator(
        onRefresh: () => blogController.fetchUserBlogs(),
        color: Colors.indigo,
        child: ListView.builder(
          padding: EdgeInsets.all(16),
          itemCount: blogController.userBlogs.length,
          itemBuilder: (context, index) {
            return _buildBlogCard(
              blogController.userBlogs[index],
              showEditDelete: true,
            );
          },
        ),
      );
    });
  }

  Widget _buildBookmarksTab() {
    return Obx(() {
      final bookmarkedBlogs = blogController.blogs
          .where((blog) => blogController.bookmarkedBlogs.contains(blog.id))
          .toList();

      if (bookmarkedBlogs.isEmpty) {
        return Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.bookmark_border, size: 80, color: Colors.grey[400]),
              SizedBox(height: 24),
              Text(
                'No bookmarked blogs',
                style: TextStyle(
                  fontSize: 20, 
                  color: Colors.grey[600],
                  fontWeight: FontWeight.w500,
                ),
              ),
              SizedBox(height: 16),
              Text(
                'Bookmark blogs to read them later',
                style: TextStyle(
                  fontSize: 16, 
                  color: Colors.grey[500],
                ),
              ),
            ],
          ),
        );
      }

      return ListView.builder(
        padding: EdgeInsets.all(16),
        itemCount: bookmarkedBlogs.length,
        itemBuilder: (context, index) {
          return _buildBlogCard(bookmarkedBlogs[index]);
        },
      );
    });
  }

  Widget _buildBlogCard(Blog blog, {bool showEditDelete = false}) {
    return Card(
      elevation: 3,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      margin: EdgeInsets.only(bottom: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Blog image
          if (blog.imageBase64 != null && blog.imageBase64!.isNotEmpty)
            ClipRRect(
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(16),
                topRight: Radius.circular(16),
              ),
              child: Container(
                height: 180,
                width: double.infinity,
                child: Builder(
                  builder: (context) {
                    try {
                      return Image.memory(
                        base64Decode(blog.imageBase64!.contains('data:image') 
                            ? blog.imageBase64!.split(',')[1] 
                            : blog.imageBase64!),
                        fit: BoxFit.cover,
                        errorBuilder: (context, error, stackTrace) {
                          return Container(
                            color: Colors.grey[200],
                            child: Center(
                              child: Icon(
                                Icons.image_not_supported,
                                size: 50,
                                color: Colors.grey[400],
                              ),
                            ),
                          );
                        },
                      );
                    } catch (e) {
                      return Container(
                        color: Colors.grey[200],
                        child: Center(
                          child: Icon(
                            Icons.image_not_supported,
                            size: 50,
                            color: Colors.grey[400],
                          ),
                        ),
                      );
                    }
                  },
                ),
              ),
            ),
          
          // Blog header
          Container(
            padding: EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    CircleAvatar(
                      backgroundColor: Colors.indigo[100],
                      radius: 16,
                      child: Text(
                        blog.author.isNotEmpty ? blog.author[0].toUpperCase() : 'A',
                        style: TextStyle(
                          color: Colors.indigo[800],
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    SizedBox(width: 8),
                    Text(
                      blog.author,
                      style: TextStyle(
                        color: Colors.grey[700],
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    Spacer(),
                    Text(
                      _formatDate(blog.createdAt),
                      style: TextStyle(
                        color: Colors.grey[500],
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 12),
                Text(
                  blog.title,
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.indigo[800],
                  ),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
                SizedBox(height: 8),
                Text(
                  blog.content,
                  style: TextStyle(
                    fontSize: 14,
                    color: Colors.grey[700],
                    height: 1.4,
                  ),
                  maxLines: 3,
                  overflow: TextOverflow.ellipsis,
                ),
                SizedBox(height: 16),
                
                // Tags
                if (blog.tags.isNotEmpty) ...[
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: blog.tags.map((tag) => Container(
                      padding: EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: Colors.indigo[50],
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: Colors.indigo[100]!),
                      ),
                      child: Text(
                        '#$tag',
                        style: TextStyle(
                          color: Colors.indigo[800],
                          fontSize: 12,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    )).toList(),
                  ),
                  SizedBox(height: 16),
                ],
                
                // Blog stats
                Row(
                  children: [
                    Icon(Icons.remove_red_eye, size: 16, color: Colors.grey[600]),
                    SizedBox(width: 4),
                    Text(
                      '${blog.views}',
                      style: TextStyle(color: Colors.grey[600], fontSize: 12),
                    ),
                    SizedBox(width: 16),
                    Icon(Icons.favorite, size: 16, color: Colors.grey[600]),
                    SizedBox(width: 4),
                    Text(
                      '${blog.likes.length}',
                      style: TextStyle(color: Colors.grey[600], fontSize: 12),
                    ),
                    SizedBox(width: 16),
                    Icon(Icons.comment, size: 16, color: Colors.grey[600]),
                    SizedBox(width: 4),
                    Text(
                      '${blog.commentCount}',
                      style: TextStyle(color: Colors.grey[600], fontSize: 12),
                    ),
                    Spacer(),
                    Obx(() => IconButton(
                      icon: Icon(
                        blogController.bookmarkedBlogs.contains(blog.id)
                            ? Icons.bookmark
                            : Icons.bookmark_border,
                        color: blogController.bookmarkedBlogs.contains(blog.id)
                            ? Colors.amber
                            : Colors.grey[600],
                      ),
                      onPressed: () => blogController.toggleBookmark(blog),
                      iconSize: 20,
                      padding: EdgeInsets.zero,
                      constraints: BoxConstraints(),
                    )),
                  ],
                ),
                
                // Action buttons
                SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: ElevatedButton.icon(
                        onPressed: () {
                          blogController.selectedBlog.value = blog;
                          blogController.incrementBlogViews(blog.id);
                          Get.to(() => BlogDetailScreen());
                        },
                        icon: Icon(Icons.visibility, size: 18),
                        label: Text('View Full Blog'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.indigo,
                          foregroundColor: Colors.white,
                          padding: EdgeInsets.symmetric(vertical: 12),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                        ),
                      ),
                    ),
                    if (showEditDelete) ...[
                      SizedBox(width: 8),
                      IconButton(
                        icon: Icon(Icons.edit, color: Colors.indigo),
                        onPressed: () {
                          blogController.selectedBlog.value = blog;
                          Get.toNamed('/edit-blog');
                        },
                        tooltip: 'Edit',
                      ),
                      IconButton(
                        icon: Icon(Icons.delete, color: Colors.red),
                        onPressed: () => _showDeleteConfirmation(blog),
                        tooltip: 'Delete',
                      ),
                    ],
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _showDeleteConfirmation(Blog blog) {
    Get.dialog(
      AlertDialog(
        title: Text('Delete Blog'),
        content: Text('Are you sure you want to delete "${blog.title}"?'),
        actions: [
          TextButton(
            child: Text('Cancel'),
            onPressed: () => Get.back(),
          ),
          TextButton(
            child: Text('Delete', style: TextStyle(color: Colors.red)),
            onPressed: () {
              Get.back();
              blogController.deleteBlog(blog.id);
            },
          ),
        ],
      ),
    );
  }

  String _formatDate(String dateString) {
    try {
      final date = DateTime.parse(dateString);
      final now = DateTime.now();
      final difference = now.difference(date);
      
      if (difference.inDays > 0) {
        return '${difference.inDays} ${difference.inDays == 1 ? 'day' : 'days'} ago';
      } else if (difference.inHours > 0) {
        return '${difference.inHours} ${difference.inHours == 1 ? 'hour' : 'hours'} ago';
      } else if (difference.inMinutes > 0) {
        return '${difference.inMinutes} ${difference.inMinutes == 1 ? 'minute' : 'minutes'} ago';
      } else {
        return 'Just now';
      }
    } catch (e) {
      return 'Unknown date';
    }
  }
}