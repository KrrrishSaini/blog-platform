import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import '../../controllers/blog_controller.dart';

class CreateBlogScreen extends StatefulWidget {
  @override
  _CreateBlogScreenState createState() => _CreateBlogScreenState();
}

class _CreateBlogScreenState extends State<CreateBlogScreen> {
  final BlogController blogController = Get.find<BlogController>();
  final TextEditingController titleController = TextEditingController();
  final TextEditingController contentController = TextEditingController();
  final TextEditingController tagsController = TextEditingController();
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();
  
  File? selectedImage;
  final ImagePicker imagePicker = ImagePicker();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Create Blog'),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
        actions: [
          Obx(() => TextButton(
            onPressed: blogController.isLoading.value ? null : _createBlog,
            child: Text(
              'Publish',
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
              ),
            ),
          )),
        ],
      ),
      body: Form(
        key: formKey,
        child: SingleChildScrollView(
          padding: EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Title Field
              TextFormField(
                controller: titleController,
                decoration: InputDecoration(
                  labelText: 'Blog Title',
                  hintText: 'Enter an engaging title...',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  filled: true,
                  fillColor: Colors.grey[50],
                ),
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w500),
                validator: (value) {
                  if (value == null || value.trim().isEmpty) {
                    return 'Please enter a title';
                  }
                  if (value.trim().length < 5) {
                    return 'Title must be at least 5 characters';
                  }
                  return null;
                },
              ),
              SizedBox(height: 20),
              
              // Image Selection
              Container(
                width: double.infinity,
                height: 200,
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.grey[300]!),
                  borderRadius: BorderRadius.circular(12),
                  color: Colors.grey[50],
                ),
                child: selectedImage != null
                    ? Stack(
                        children: [
                          ClipRRect(
                            borderRadius: BorderRadius.circular(12),
                            child: Image.file(
                              selectedImage!,
                              width: double.infinity,
                              height: double.infinity,
                              fit: BoxFit.cover,
                            ),
                          ),
                          Positioned(
                            top: 8,
                            right: 8,
                            child: CircleAvatar(
                              backgroundColor: Colors.red,
                              radius: 16,
                              child: IconButton(
                                icon: Icon(Icons.close, size: 16, color: Colors.white),
                                onPressed: () {
                                  setState(() {
                                    selectedImage = null;
                                  });
                                },
                              ),
                            ),
                          ),
                        ],
                      )
                    : InkWell(
                        onTap: _pickImage,
                        borderRadius: BorderRadius.circular(12),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              Icons.add_photo_alternate,
                              size: 48,
                              color: Colors.grey[400],
                            ),
                            SizedBox(height: 8),
                            Text(
                              'Add Cover Image',
                              style: TextStyle(
                                fontSize: 16,
                                color: Colors.grey[600],
                              ),
                            ),
                            SizedBox(height: 4),
                            Text(
                              'Tap to select from gallery',
                              style: TextStyle(
                                fontSize: 12,
                                color: Colors.grey[500],
                              ),
                            ),
                          ],
                        ),
                      ),
              ),
              SizedBox(height: 20),
              
              // Content Field
              TextFormField(
                controller: contentController,
                maxLines: 12,
                decoration: InputDecoration(
                  labelText: 'Blog Content',
                  hintText: 'Write your blog content here...',
                  alignLabelWithHint: true,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  filled: true,
                  fillColor: Colors.grey[50],
                ),
                style: TextStyle(fontSize: 16, height: 1.5),
                validator: (value) {
                  if (value == null || value.trim().isEmpty) {
                    return 'Please enter blog content';
                  }
                  if (value.trim().length < 50) {
                    return 'Content must be at least 50 characters';
                  }
                  return null;
                },
              ),
              SizedBox(height: 20),
              
              // Tags Field
              TextFormField(
                controller: tagsController,
                decoration: InputDecoration(
                  labelText: 'Tags',
                  hintText: 'Enter tags separated by commas (e.g., tech, flutter, mobile)',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  filled: true,
                  fillColor: Colors.grey[50],
                  prefixIcon: Icon(Icons.tag),
                ),
              ),
              SizedBox(height: 30),
              
              // Create Button
              Obx(() => SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton(
                  onPressed: blogController.isLoading.value ? null : _createBlog,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: blogController.isLoading.value
                      ? Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            SizedBox(
                              width: 20,
                              height: 20,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                              ),
                            ),
                            SizedBox(width: 12),
                            Text(
                              'Publishing...',
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                                color: Colors.white,
                              ),
                            ),
                          ],
                        )
                      : Text(
                          'Publish Blog',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                ),
              )),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _pickImage() async {
    try {
      final XFile? image = await imagePicker.pickImage(
        source: ImageSource.gallery,
        maxWidth: 1024,
        maxHeight: 1024,
        imageQuality: 80,
      );
      
      if (image != null) {
        setState(() {
          selectedImage = File(image.path);
        });
      }
    } catch (e) {
      Get.snackbar('Error', 'Failed to pick image: $e');
    }
  }

  Future<String?> _convertImageToBase64() async {
    if (selectedImage == null) return null;
    
    try {
      List<int> imageBytes = await selectedImage!.readAsBytes();
      String base64String = base64Encode(imageBytes);
      String mimeType = selectedImage!.path.toLowerCase().endsWith('.png') 
          ? 'image/png' 
          : 'image/jpeg';
      return 'data:$mimeType;base64,$base64String';
    } catch (e) {
      Get.snackbar('Error', 'Failed to process image: $e');
      return null;
    }
  }

  Future<void> _createBlog() async {
    if (!formKey.currentState!.validate()) return;

    try {
      String? imageBase64;
      if (selectedImage != null) {
        imageBase64 = await _convertImageToBase64();
      }

      List<String> tags = tagsController.text
          .split(',')
          .map((tag) => tag.trim())
          .where((tag) => tag.isNotEmpty)
          .toList();

      Map<String, dynamic> blogData = {
        'title': titleController.text.trim(),
        'content': contentController.text.trim(),
        'tags': tags,
        'imageBase64': imageBase64,
      };

      bool success = await blogController.createBlog(blogData);
      
      if (success) {
        // Clear form
        titleController.clear();
        contentController.clear();
        tagsController.clear();
        setState(() {
          selectedImage = null;
        });
      }
    } catch (e) {
      Get.snackbar('Error', 'Failed to create blog: $e');
    }
  }

  @override
  void dispose() {
    titleController.dispose();
    contentController.dispose();
    tagsController.dispose();
    super.dispose();
  }
}