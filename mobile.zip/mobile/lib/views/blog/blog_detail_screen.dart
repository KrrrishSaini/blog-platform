import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import '../../controllers/blog_controller.dart';
import '../../controllers/auth_controller.dart';
import '../../models/blog.dart';

class Comment {
  final String id;
  final String username;
  final String content;
  final String createdAt;

  Comment({
    required this.id,
    required this.username,
    required this.content,
    required this.createdAt,
  });

  factory Comment.fromJson(Map<String, dynamic> json) {
    return Comment(
      id: json['id'],
      username: json['username'],
      content: json['content'],
      createdAt: json['createdAt'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'username': username,
      'content': content,
      'createdAt': createdAt,
    };
  }
}

class BlogDetailScreen extends StatefulWidget {
  @override
  _BlogDetailScreenState createState() => _BlogDetailScreenState();
}

class _BlogDetailScreenState extends State<BlogDetailScreen> {
  final BlogController blogController = Get.find<BlogController>();
  final AuthController authController = Get.find<AuthController>();
  final TextEditingController commentController = TextEditingController();
  
  List<Comment> comments = [];
  bool isLoading = true;
  bool isLiked = false;

  @override
  void initState() {
    super.initState();
    // Delay loading comments until after the widget is built
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _loadComments();
      _checkIfLiked();
    });
  }
  
  void _checkIfLiked() {
    if (blogController.selectedBlog.value != null && authController.currentUser.value != null) {
      setState(() {
        isLiked = blogController.selectedBlog.value!.likes.contains(authController.currentUser.value!.id);
      });
    }
  }

  Future<void> _loadComments() async {
    if (mounted) {
      setState(() {
        isLoading = true;
      });
    }

    try {
      final prefs = await SharedPreferences.getInstance();
      final blogId = blogController.selectedBlog.value?.id ?? '';
      
      if (blogId.isEmpty) {
        if (mounted) {
          setState(() {
            isLoading = false;
          });
        }
        return;
      }
      
      final commentsJson = prefs.getStringList('comments_$blogId') ?? [];
      
      List<Comment> loadedComments = [];
      for (var jsonStr in commentsJson) {
        try {
          loadedComments.add(Comment.fromJson(jsonDecode(jsonStr)));
        } catch (e) {
          print('Error parsing comment: $e');
        }
      }
      
      // Sort comments by date (newest first)
      loadedComments.sort((a, b) {
        try {
          return DateTime.parse(b.createdAt).compareTo(DateTime.parse(a.createdAt));
        } catch (e) {
          return 0;
        }
      });
      
      if (mounted) {
        setState(() {
          comments = loadedComments;
          isLoading = false;
        });
        
        // Update the blog's comment count
        if (blogController.selectedBlog.value != null) {
          int blogIndex = blogController.blogs.indexWhere((blog) => blog.id == blogId);
          if (blogIndex != -1) {
            Blog updatedBlog = Blog(
              id: blogController.blogs[blogIndex].id,
              title: blogController.blogs[blogIndex].title,
              content: blogController.blogs[blogIndex].content,
              author: blogController.blogs[blogIndex].author,
              userId: blogController.blogs[blogIndex].userId,
              createdAt: blogController.blogs[blogIndex].createdAt,
              likes: blogController.blogs[blogIndex].likes,
              views: blogController.blogs[blogIndex].views,
              tags: blogController.blogs[blogIndex].tags,
              imageBase64: blogController.blogs[blogIndex].imageBase64,
              commentCount: loadedComments.length,
            );
            blogController.blogs[blogIndex] = updatedBlog;
            
            if (blogController.selectedBlog.value?.id == blogId) {
              blogController.selectedBlog.value = updatedBlog;
            }
          }
        }
      }
    } catch (e) {
      print('Error loading comments: $e');
      if (mounted) {
        setState(() {
          isLoading = false;
        });
      }
    }
  }

  Future<void> _addComment() async {
    if (commentController.text.trim().isEmpty || 
        authController.currentUser.value == null ||
        blogController.selectedBlog.value == null) {
      return;
    }
    
    try {
      final blogId = blogController.selectedBlog.value!.id;
      final prefs = await SharedPreferences.getInstance();
      
      // Get existing comments first
      final commentsJson = prefs.getStringList('comments_$blogId') ?? [];
      
      List<Comment> existingComments = [];
      for (var jsonStr in commentsJson) {
        try {
          existingComments.add(Comment.fromJson(jsonDecode(jsonStr)));
        } catch (e) {
          print('Error parsing existing comment: $e');
        }
      }
      
      // Create new comment
      Comment newComment = Comment(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        username: authController.currentUser.value?.name ?? 'Anonymous',
        content: commentController.text.trim(),
        createdAt: DateTime.now().toIso8601String(),
      );
      
      // Add to existing comments
      existingComments.add(newComment);
      
      // Convert back to JSON strings
      List<String> updatedCommentsJson = existingComments.map((comment) {
        return jsonEncode(comment.toJson());
      }).toList();
      
      // Save to shared preferences
      await prefs.setStringList('comments_$blogId', updatedCommentsJson);
      
      // Update UI - sort by newest first
      existingComments.sort((a, b) {
        try {
          return DateTime.parse(b.createdAt).compareTo(DateTime.parse(a.createdAt));
        } catch (e) {
          return 0;
        }
      });
      
      setState(() {
        comments = existingComments;
        commentController.clear();
      });
      
      // Update blog comment count
      int blogIndex = blogController.blogs.indexWhere((blog) => blog.id == blogId);
      if (blogIndex != -1) {
        Blog updatedBlog = Blog(
          id: blogController.blogs[blogIndex].id,
          title: blogController.blogs[blogIndex].title,
          content: blogController.blogs[blogIndex].content,
          author: blogController.blogs[blogIndex].author,
          userId: blogController.blogs[blogIndex].userId,
          createdAt: blogController.blogs[blogIndex].createdAt,
          likes: blogController.blogs[blogIndex].likes,
          views: blogController.blogs[blogIndex].views,
          tags: blogController.blogs[blogIndex].tags,
          imageBase64: blogController.blogs[blogIndex].imageBase64,
          commentCount: existingComments.length,
        );
        blogController.blogs[blogIndex] = updatedBlog;
        
        if (blogController.selectedBlog.value?.id == blogId) {
          blogController.selectedBlog.value = updatedBlog;
        }
      }
      
      Get.snackbar(
        'Comment Posted', 
        'Your comment has been added',
        backgroundColor: Colors.green[100],
        colorText: Colors.green[800],
        snackPosition: SnackPosition.BOTTOM,
        margin: EdgeInsets.all(16),
        borderRadius: 8,
      );
    } catch (e) {
      print('Error adding comment: $e');
      Get.snackbar(
        'Error', 
        'Failed to add comment',
        backgroundColor: Colors.red[100],
        colorText: Colors.red[800],
        snackPosition: SnackPosition.BOTTOM,
        margin: EdgeInsets.all(16),
        borderRadius: 8,
      );
    }
  }

  void _toggleLike() {
    if (blogController.selectedBlog.value != null && authController.currentUser.value != null) {
      blogController.toggleLike(blogController.selectedBlog.value!);
      setState(() {
        isLiked = !isLiked;
      });
    }
  }

  Widget _buildCommentCard(Comment comment) {
    return Card(
      elevation: 2,
      margin: EdgeInsets.symmetric(vertical: 8),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(
                  backgroundColor: _getAvatarColor(comment.username),
                  child: Text(
                    comment.username.isNotEmpty ? comment.username[0].toUpperCase() : 'A',
                    style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                  ),
                ),
                SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        comment.username,
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                        ),
                      ),
                      Text(
                        _formatDate(comment.createdAt),
                        style: TextStyle(
                          color: Colors.grey[600],
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            SizedBox(height: 12),
            Container(
              padding: EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.grey[50],
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                comment.content,
                style: TextStyle(
                  fontSize: 15,
                  height: 1.4,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
  
  Color _getAvatarColor(String username) {
    if (username.isEmpty) return Colors.blue;
    
    // Generate a consistent color based on the username
    final int hash = username.hashCode;
    final List<Color> colors = [
      Colors.blue,
      Colors.red,
      Colors.green,
      Colors.purple,
      Colors.orange,
      Colors.teal,
      Colors.pink,
      Colors.indigo,
    ];
    
    return colors[hash.abs() % colors.length];
  }
  
  String _formatDate(String dateString) {
    try {
      final date = DateTime.parse(dateString);
      final now = DateTime.now();
      final difference = now.difference(date);
      
      if (difference.inDays > 0) {
        return '${difference.inDays} ${difference.inDays == 1 ? 'day' : 'days'} ago';
      } else if (difference.inHours > 0) {
        return '${difference.inHours} ${difference.inHours == 1 ? 'hour' : 'hours'} ago';
      } else if (difference.inMinutes > 0) {
        return '${difference.inMinutes} ${difference.inMinutes == 1 ? 'minute' : 'minutes'} ago';
      } else {
        return 'Just now';
      }
    } catch (e) {
      return 'Unknown date';
    }
  }
  
  ImageProvider _getImageFromBase64(String base64String) {
    try {
      // Check if the string contains data URI prefix
      if (base64String.contains('data:image')) {
        // Extract the base64 part after the comma
        base64String = base64String.split(',')[1];
      }
      
      // Decode the base64 string
      final bytes = base64Decode(base64String);
      return MemoryImage(bytes);
    } catch (e) {
      print('Error decoding image: $e');
      // Return a placeholder image or throw to be caught by the caller
      throw Exception('Invalid image data');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Blog Details'),
        backgroundColor: Colors.indigo,
        foregroundColor: Colors.white,
        elevation: 0,
        actions: [
          IconButton(
            icon: Obx(() => Icon(
              blogController.selectedBlog.value != null && 
              blogController.bookmarkedBlogs.contains(blogController.selectedBlog.value!.id)
                ? Icons.bookmark
                : Icons.bookmark_border,
              color: blogController.selectedBlog.value != null && 
                     blogController.bookmarkedBlogs.contains(blogController.selectedBlog.value!.id)
                ? Colors.amber
                : Colors.white
            )),
            onPressed: () {
              if (blogController.selectedBlog.value != null) {
                blogController.toggleBookmark(blogController.selectedBlog.value!);
              }
            },
          ),
          IconButton(
            icon: Icon(Icons.share),
            onPressed: () {
              Get.snackbar(
                'Share', 
                'Sharing functionality coming soon!',
                backgroundColor: Colors.blue[100],
                colorText: Colors.blue[800],
                snackPosition: SnackPosition.BOTTOM,
                margin: EdgeInsets.all(16),
                borderRadius: 8,
              );
            },
          ),
        ],
      ),
      body: Obx(() {
        final blog = blogController.selectedBlog.value;
        
        if (blog == null) {
          return Center(child: Text('Blog not found'));
        }
        
        return Stack(
          children: [
            // Background gradient
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Colors.indigo.withOpacity(0.1), Colors.white],
                  stops: [0.0, 0.3],
                ),
              ),
            ),
            
            // Content
            SingleChildScrollView(
              padding: EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Blog Header
                  Container(
                    padding: EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.05),
                          blurRadius: 10,
                          offset: Offset(0, 5),
                        ),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          blog.title,
                          style: TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                            color: Colors.indigo[800],
                          ),
                        ),
                        SizedBox(height: 12),
                        Row(
                          children: [
                            CircleAvatar(
                              backgroundColor: Colors.indigo[100],
                              radius: 16,
                              child: Text(
                                blog.author.isNotEmpty ? blog.author[0].toUpperCase() : 'A',
                                style: TextStyle(
                                  color: Colors.indigo[800],
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                            SizedBox(width: 8),
                            Text(
                              blog.author,
                              style: TextStyle(
                                color: Colors.indigo[800],
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                            Spacer(),
                            Icon(Icons.calendar_today, size: 14, color: Colors.grey[600]),
                            SizedBox(width: 4),
                            Text(
                              _formatDate(blog.createdAt),
                              style: TextStyle(color: Colors.grey[600]),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 20),
                  
                  // Blog Image
                  if (blog.imageBase64 != null && blog.imageBase64!.isNotEmpty)
                    Builder(
                      builder: (context) {
                        try {
                          return Container(
                            height: 220,
                            width: double.infinity,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(16),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.1),
                                  blurRadius: 10,
                                  offset: Offset(0, 5),
                                ),
                              ],
                            ),
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(16),
                              child: Image(
                                image: _getImageFromBase64(blog.imageBase64!),
                                fit: BoxFit.cover,
                              ),
                            ),
                          );
                        } catch (e) {
                          return Container(
                            height: 200,
                            width: double.infinity,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(16),
                              color: Colors.grey[200],
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.05),
                                  blurRadius: 10,
                                  offset: Offset(0, 5),
                                ),
                              ],
                            ),
                            child: Center(
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(Icons.image_not_supported, size: 50, color: Colors.grey),
                                  SizedBox(height: 8),
                                  Text(
                                    'Image not available',
                                    style: TextStyle(color: Colors.grey[600]),
                                  ),
                                ],
                              ),
                            ),
                          );
                        }
                      },
                    ),
                  SizedBox(height: 20),
                  
                  // Blog Content
                  Container(
                    padding: EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.05),
                          blurRadius: 10,
                          offset: Offset(0, 5),
                        ),
                      ],
                    ),
                    child: Text(
                      blog.content,
                      style: TextStyle(
                        fontSize: 16,
                        height: 1.6,
                        color: Colors.grey[800],
                      ),
                    ),
                  ),
                  SizedBox(height: 20),
                  
                  // Blog Stats and Actions
                  Container(
                    padding: EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.05),
                          blurRadius: 10,
                          offset: Offset(0, 5),
                        ),
                      ],
                    ),
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            // Like button
                            InkWell(
                              onTap: _toggleLike,
                              child: Column(
                                children: [
                                  Icon(
                                    isLiked ? Icons.favorite : Icons.favorite_border,
                                    color: isLiked ? Colors.red : Colors.grey[600],
                                    size: 28,
                                  ),
                                  SizedBox(height: 4),
                                  Text(
                                    '${blog.likes.length} Likes',
                                    style: TextStyle(
                                      color: Colors.grey[600],
                                      fontSize: 12,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            
                            // Views
                            Column(
                              children: [
                                Icon(
                                  Icons.remove_red_eye,
                                  color: Colors.grey[600],
                                  size: 28,
                                ),
                                SizedBox(height: 4),
                                Text(
                                  '${blog.views} Views',
                                  style: TextStyle(
                                    color: Colors.grey[600],
                                    fontSize: 12,
                                  ),
                                ),
                              ],
                            ),
                            
                            // Comments
                            Column(
                              children: [
                                Icon(
                                  Icons.comment,
                                  color: Colors.grey[600],
                                  size: 28,
                                ),
                                SizedBox(height: 4),
                                Text(
                                  '${comments.length} Comments',
                                  style: TextStyle(
                                    color: Colors.grey[600],
                                    fontSize: 12,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 20),
                  
                  // Tags
                  if (blog.tags.isNotEmpty) ...[
                    Container(
                      padding: EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(16),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.05),
                            blurRadius: 10,
                            offset: Offset(0, 5),
                          ),
                        ],
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Tags',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: Colors.indigo[800],
                            ),
                          ),
                          SizedBox(height: 12),
                          Wrap(
                            spacing: 8,
                            runSpacing: 8,
                            children: blog.tags.map((tag) => Container(
                              padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                              decoration: BoxDecoration(
                                color: Colors.indigo[50],
                                borderRadius: BorderRadius.circular(20),
                                border: Border.all(color: Colors.indigo[100]!),
                              ),
                              child: Text(
                                '#$tag',
                                style: TextStyle(
                                  color: Colors.indigo[800],
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            )).toList(),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(height: 30),
                  ],
                  
                  // Comments Section
                  Container(
                    padding: EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.05),
                          blurRadius: 10,
                          offset: Offset(0, 5),
                        ),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Comments (${comments.length})',
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: Colors.indigo[800],
                          ),
                        ),
                        SizedBox(height: 16),
                        
                        // Comment Input
                        Container(
                          padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                          decoration: BoxDecoration(
                            color: Colors.grey[50],
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: Colors.grey[300]!),
                          ),
                          child: Row(
                            children: [
                              CircleAvatar(
                                backgroundColor: Colors.indigo[100],
                                radius: 16,
                                child: Text(
                                  authController.currentUser.value?.name.isNotEmpty == true
                                      ? authController.currentUser.value!.name[0].toUpperCase()
                                      : 'A',
                                  style: TextStyle(
                                    color: Colors.indigo[800],
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                              SizedBox(width: 12),
                              Expanded(
                                child: TextField(
                                  controller: commentController,
                                  decoration: InputDecoration(
                                    hintText: 'Add a comment...',
                                    border: InputBorder.none,
                                    hintStyle: TextStyle(color: Colors.grey[400]),
                                  ),
                                  maxLines: 3,
                                  minLines: 1,
                                ),
                              ),
                              IconButton(
                                icon: Icon(Icons.send, color: Colors.indigo),
                                onPressed: _addComment,
                              ),
                            ],
                          ),
                        ),
                        SizedBox(height: 20),
                        
                        // Comments List
                        isLoading
                          ? Center(
                              child: Padding(
                                padding: EdgeInsets.symmetric(vertical: 20),
                                child: CircularProgressIndicator(
                                  valueColor: AlwaysStoppedAnimation<Color>(Colors.indigo),
                                ),
                              ),
                            )
                          : comments.isEmpty
                            ? Center(
                                child: Padding(
                                  padding: EdgeInsets.symmetric(vertical: 20),
                                  child: Column(
                                    children: [
                                      Icon(
                                        Icons.chat_bubble_outline,
                                        size: 48,
                                        color: Colors.grey[400],
                                      ),
                                      SizedBox(height: 16),
                                      Text(
                                        'No comments yet. Be the first to comment!',
                                        style: TextStyle(
                                          color: Colors.grey[600],
                                          fontSize: 16,
                                        ),
                                        textAlign: TextAlign.center,
                                      ),
                                    ],
                                  ),
                                ),
                              )
                            : Column(
                                children: comments.map((comment) => _buildCommentCard(comment)).toList(),
                              ),
                      ],
                    ),
                  ),
                  SizedBox(height: 100), // Extra space at bottom
                ],
              ),
            ),
          ],
        );
      }),
    );
  }
}