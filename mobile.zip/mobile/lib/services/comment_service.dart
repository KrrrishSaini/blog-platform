import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/comment.dart';

class CommentService {
  // Singleton pattern
  static final CommentService _instance = CommentService._internal();
  factory CommentService() => _instance;
  CommentService._internal();
  
  // Cache for comments
  final Map<String, List<Comment>> _commentsCache = {};
  
  // Get comments for a blog
  Future<List<Comment>> getCommentsForBlog(String blogId) async {
    // Check cache first
    if (_commentsCache.containsKey(blogId)) {
      return _commentsCache[blogId]!;
    }
    
    try {
      final prefs = await SharedPreferences.getInstance();
      final commentsJson = prefs.getStringList('comments_$blogId') ?? [];
      
      if (commentsJson.isEmpty) {
        _commentsCache[blogId] = [];
        return [];
      }
      
      List<Comment> comments = commentsJson.map((jsonStr) {
        Map<String, dynamic> json = jsonDecode(jsonStr);
        return Comment.fromJson(json);
      }).toList();
      
      // Sort by date (newest first)
      comments.sort((a, b) => 
        DateTime.parse(b.createdAt).compareTo(DateTime.parse(a.createdAt)));
      
      // Cache the result
      _commentsCache[blogId] = comments;
      
      return comments;
    } catch (e) {
      print('Error loading comments: $e');
      return [];
    }
  }
  
  // Add a comment
  Future<bool> addComment(String blogId, Comment comment) async {
    try {
      // Get existing comments
      List<Comment> comments = await getCommentsForBlog(blogId);
      
      // Add new comment
      comments.insert(0, comment); // Add at the beginning (newest first)
      
      // Update cache
      _commentsCache[blogId] = comments;
      
      // Save to storage
      final prefs = await SharedPreferences.getInstance();
      List<String> commentsJson = comments.map((c) => jsonEncode(c.toJson())).toList();
      await prefs.setStringList('comments_$blogId', commentsJson);
      
      return true;
    } catch (e) {
      print('Error adding comment: $e');
      return false;
    }
  }
  
  // Get comment count
  Future<int> getCommentCount(String blogId) async {
    List<Comment> comments = await getCommentsForBlog(blogId);
    return comments.length;
  }
  
  // Clear cache for testing
  void clearCache() {
    _commentsCache.clear();
  }
}