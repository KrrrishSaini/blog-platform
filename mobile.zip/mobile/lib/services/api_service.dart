import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/user.dart';
import '../models/blog.dart';

import 'dart:io' show Platform;
import 'package:flutter/foundation.dart' show kIsWeb;

class ApiService {
  // Use the IP address of your machine instead of localhost
  static String get baseUrl {
    // For web, use the window.location.hostname
    if (kIsWeb) {
      return 'http://127.0.0.1:5050/api';
    }
    // For mobile emulators
    return 'http://10.0.2.2:5050/api';
  }
  
  static Map<String, String> _getHeaders({String? token}) {
    Map<String, String> headers = {
      'Content-Type': 'application/json',
    };
    
    if (token != null) {
      headers['Authorization'] = 'Bearer $token';
    }
    
    return headers;
  }

  // Auth APIs
  static Future<Map<String, dynamic>> login(String email, String password) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/auth/login'),
        headers: _getHeaders(),
        body: jsonEncode({
          'email': email,
          'password': password,
        }),
      );

      if (response.statusCode == 200) {
        final Map<String, dynamic> data = jsonDecode(response.body);
        return data;
      } else {
        final errorMsg = response.body.isNotEmpty 
          ? 'Failed to login: ${response.body}' 
          : 'Failed to login: Server returned ${response.statusCode}';
        throw Exception(errorMsg);
      }
    } catch (e) {
      print('Login error: $e');
      throw Exception('Failed to connect to server. Please check your internet connection.');
    }
  }

  static Future<Map<String, dynamic>> register(String name, String email, String password) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/auth/register'),
        headers: _getHeaders(),
        body: jsonEncode({
          'name': name,
          'email': email,
          'password': password,
        }),
      );

      if (response.statusCode == 201) {
        final Map<String, dynamic> data = jsonDecode(response.body);
        return data;
      } else {
        final errorMsg = response.body.isNotEmpty 
          ? 'Failed to register: ${response.body}' 
          : 'Failed to register: Server returned ${response.statusCode}';
        throw Exception(errorMsg);
      }
    } catch (e) {
      print('Register error: $e');
      throw Exception('Failed to connect to server. Please check your internet connection.');
    }
  }

  // Blog APIs
  static Future<List<Blog>> getAllBlogs() async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/blogs'),
        headers: _getHeaders(),
      );

      if (response.statusCode == 200) {
        List<dynamic> data = jsonDecode(response.body);
        return data.map((json) => Blog.fromJson(json)).toList();
      } else {
        print('Failed to fetch blogs: ${response.statusCode}, ${response.body}');
        throw Exception('Failed to fetch blogs');
      }
    } catch (e) {
      print('Error fetching blogs: $e');
      // Return empty list instead of throwing exception
      return [];
    }
  }

  static Future<List<Blog>> getUserBlogs(String token) async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/blogs/user'),
        headers: _getHeaders(token: token),
      );

      if (response.statusCode == 200) {
        List<dynamic> data = jsonDecode(response.body);
        return data.map((json) => Blog.fromJson(json)).toList();
      } else {
        print('Failed to fetch user blogs: ${response.statusCode}, ${response.body}');
        throw Exception('Failed to fetch user blogs');
      }
    } catch (e) {
      print('Error fetching user blogs: $e');
      // Return empty list instead of throwing exception
      return [];
    }
  }

  static Future<Blog> getBlogById(String id) async {
    final response = await http.get(
      Uri.parse('$baseUrl/blogs/$id'),
      headers: _getHeaders(),
    );

    if (response.statusCode == 200) {
      return Blog.fromJson(jsonDecode(response.body));
    } else {
      throw Exception('Failed to fetch blog');
    }
  }

  static Future<Blog> createBlog(String token, Map<String, dynamic> blogData) async {
    final response = await http.post(
      Uri.parse('$baseUrl/blogs'),
      headers: _getHeaders(token: token),
      body: jsonEncode(blogData),
    );

    if (response.statusCode == 201) {
      return Blog.fromJson(jsonDecode(response.body));
    } else {
      throw Exception('Failed to create blog: ${response.body}');
    }
  }

  static Future<void> deleteBlog(String token, String id) async {
    final response = await http.delete(
      Uri.parse('$baseUrl/blogs/$id'),
      headers: _getHeaders(token: token),
    );

    if (response.statusCode != 200) {
      throw Exception('Failed to delete blog');
    }
  }

  static Future<void> likeBlog(String token, String id) async {
    final response = await http.put(
      Uri.parse('$baseUrl/blogs/$id/like'),
      headers: _getHeaders(token: token),
    );

    if (response.statusCode != 200) {
      throw Exception('Failed to like blog');
    }
  }

  static Future<void> unlikeBlog(String token, String id) async {
    final response = await http.put(
      Uri.parse('$baseUrl/blogs/$id/unlike'),
      headers: _getHeaders(token: token),
    );

    if (response.statusCode != 200) {
      throw Exception('Failed to unlike blog');
    }
  }
  
  static Future<void> incrementBlogViews(String id) async {
    try {
      final response = await http.put(
        Uri.parse('$baseUrl/blogs/$id/view'),
        headers: _getHeaders(),
      );

      if (response.statusCode != 200) {
        throw Exception('Failed to increment blog views');
      }
    } catch (e) {
      print('Error incrementing blog views: $e');
      // Silently fail as this is not critical
    }
  }
}