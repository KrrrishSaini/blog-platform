// src/components/Navbar.jsx
import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import { logout } from '../features/auth/authSlice';
import './Navbar.scss';

const Navbar = () => {
  const { user } = useSelector(state => state.auth);
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const handleLogout = () => {
    dispatch(logout());
    navigate('/');
  };

  return (
    <nav className="navbar">
      <div className="navbar-container">
        <Link to="/" className="navbar-brand">
          BlogPlatform
        </Link>
        
        <div className="navbar-nav">
          <Link to="/" className="navbar-link">Home</Link>
          <Link to="/blogs" className="navbar-link">All Blogs</Link>
          
          {user ? (
            // Show these links when user is logged in
            <>
              <Link to="/dashboard" className="navbar-link">My Blogs</Link>
              <Link to="/create" className="navbar-link">Create Blog</Link>
              <Link to="/bookmarks" className="navbar-link">Bookmarks</Link>
              <Link to="/profile" className="navbar-link">Profile</Link>
              {user.role === 'admin' && <Link to="/admin" className="navbar-link">Admin</Link>}
            </>
          ) : (
            // Show these links when user is not logged in
            <>
              <Link to="/login" className="navbar-link">Login</Link>
              <Link to="/register" className="navbar-link">Register</Link>
            </>
          )}
        </div>

        {user && (
          <div className="navbar-user-section">
            <span className="navbar-user">Welcome, {user.name || user.email}!</span>
            <button onClick={handleLogout} className="navbar-logout-btn">Logout</button>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;