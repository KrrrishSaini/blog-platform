import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { deleteBlog, likeBlog, unlikeBlog, bookmarkBlog, removeBookmark, checkBookmarkStatus } from '../features/blogs/blogSlice';
import { Link, useNavigate } from 'react-router-dom';
import './BlogCard.scss';

const BlogCard = ({ blog, showAllBlogsView = false }) => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { user } = useSelector((state) => state.auth);
  const { blogs, userBlogs, bookmarkStatuses } = useSelector((state) => state.blogs);
  const userId = user?.id;
  const [isLiking, setIsLiking] = useState(false);
  const [isBookmarking, setIsBookmarking] = useState(false);

  // Get the latest blog data from Redux store
  const latestBlog = showAllBlogsView 
    ? blogs.find(b => b.id === blog.id) || blog
    : userBlogs.find(b => b.id === blog.id) || blog;



  const handleDelete = () => {
    if (window.confirm('Are you sure you want to delete this blog?')) {
      dispatch(deleteBlog(latestBlog.id));
    }
  };

  const handleEdit = () => {
    navigate(`/edit/${latestBlog.id}`);
  };

  const handleLikeToggle = async () => {
    if (!user) {
      alert('Please log in to like blogs');
      return;
    }

    setIsLiking(true);
    try {
      if (hasLiked) {
        await dispatch(unlikeBlog(latestBlog.id)).unwrap();
      } else {
        await dispatch(likeBlog(latestBlog.id)).unwrap();
      }
    } catch (error) {
      console.error('Failed to toggle like:', error);
      alert('Failed to update like. Please try again.');
    } finally {
      setIsLiking(false);
    }
  };

  const hasLiked = latestBlog.likes?.includes(userId);
  const isBookmarked = bookmarkStatuses[latestBlog.id] || false;

  // Check bookmark status when component loads and user is authenticated
  useEffect(() => {
    if (user && latestBlog && bookmarkStatuses[latestBlog.id] === undefined) {
      dispatch(checkBookmarkStatus(latestBlog.id));
    }
  }, [dispatch, user, latestBlog, bookmarkStatuses]);

  const handleBookmarkToggle = async () => {
    if (!user) {
      navigate('/login');
      return;
    }

    setIsBookmarking(true);
    try {
      if (isBookmarked) {
        await dispatch(removeBookmark(latestBlog.id));
      } else {
        await dispatch(bookmarkBlog(latestBlog.id));
      }
    } catch (error) {
      console.error('Error toggling bookmark:', error);
    } finally {
      setIsBookmarking(false);
    }
  };

  return (
    <div className={`blog-card ${isLiking ? 'loading' : ''} animate-in`}>
      {latestBlog.imageBase64 && (
        <div className="blog-image">
          <img src={latestBlog.imageBase64} alt={latestBlog.title} />
        </div>
      )}
      
      <div className="blog-card-header">
        <h3 className="blog-title">{latestBlog.title}</h3>
        <p className="blog-content-preview">
          {latestBlog.content.length > 150 ? `${latestBlog.content.substring(0, 150)}...` : latestBlog.content}
        </p>
      </div>
      
      <div className="blog-meta">
        <div className="meta-item">
          <span className="meta-label">Author:</span>
          <span>{latestBlog.author || 'Unknown'}</span>
        </div>
        <div className="meta-item">
          <span className="meta-label">Created:</span>
          <span>{new Date(latestBlog.createdAt).toLocaleDateString()}</span>
        </div>
      </div>

      {latestBlog.tags && latestBlog.tags.length > 0 && (
        <div className="blog-tags">
          {latestBlog.tags.map((tag, index) => (
            <span key={index} className="blog-tag">#{tag}</span>
          ))}
        </div>
      )}

      <div className="blog-stats">
        <div className="stat-item">
          <span className="stat-icon">👍</span>
          <span className="stat-count">{latestBlog.likes?.length || 0}</span>
          <span>Likes</span>
        </div>
        <div className="stat-item">
          <span className="stat-icon">👁️</span>
          <span className="stat-count">{latestBlog.views || 0}</span>
          <span>Views</span>
        </div>
        <div className="stat-item">
          <span className="stat-icon">💬</span>
          <span className="stat-count">{latestBlog.commentCount ?? latestBlog.comments?.length ?? 0}</span>
          <span>Comments</span>
        </div>
      </div>

      <div className="blog-actions">
        <button 
          onClick={handleLikeToggle}
          disabled={isLiking}
          className={`action-btn btn-like ${hasLiked ? 'liked' : ''}`}
        >
          <span>{hasLiked ? '👍' : '👍'}</span>
          {isLiking ? 'Loading...' : (hasLiked ? 'Liked' : 'Like')}
        </button>

        <button 
          onClick={handleBookmarkToggle}
          disabled={isBookmarking}
          className={`action-btn btn-bookmark ${isBookmarked ? 'bookmarked' : ''}`}
        >
          <span>{isBookmarked ? '🔖' : '📑'}</span>
          {isBookmarking ? 'Loading...' : (isBookmarked ? 'Bookmarked' : 'Bookmark')}
        </button>

        {latestBlog.userId === userId && (
          <>
            <button 
              onClick={handleEdit}
              className="action-btn btn-edit"
            >
              <span>✏️</span>
              Edit
            </button>
            <button 
              onClick={handleDelete}
              className="action-btn btn-delete"
            >
              <span>🗑️</span>
              Delete
            </button>
          </>
        )}

        <Link 
          to={`/blogs/${latestBlog.id}`}
          className="action-btn btn-view"
        >
          <span>📖</span>
          View Full Blog
        </Link>
      </div>
    </div>
  );
};

export default BlogCard;