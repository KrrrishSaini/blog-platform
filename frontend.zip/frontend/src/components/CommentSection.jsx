import React, { useState, useEffect, useCallback } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { updateCommentCount } from '../features/blogs/blogSlice';
import api from '../services/api';

const CommentSection = ({ blogId }) => {
  const dispatch = useDispatch();
  const [comment, setComment] = useState('');
  const [allComments, setAllComments] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState(null);
  const [submitStatus, setSubmitStatus] = useState(null);
  const { user } = useSelector((state) => state.auth);

  // ✅ useCallback ensures fetchComments is stable and doesn't trigger useEffect on every render
  const fetchComments = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const res = await api.get(`/blogs/${blogId}/comments`);
      setAllComments(res.data);
    } catch (err) {
      console.error('Failed to load comments', err);
      setError('Failed to load comments');
    } finally {
      setIsLoading(false);
    }
  }, [blogId]); // depends only on blogId

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!comment.trim()) return;

    if (!user) {
      alert('Please log in to post a comment');
      return;
    }

    setIsSubmitting(true);
    setSubmitStatus(null);
    setError(null);

    try {
      await api.post(`/blogs/${blogId}/comments`, { content: comment });
      setComment('');
      setSubmitStatus('success');
      fetchComments(); // Refresh comments after posting
      
      // Update comment count in Redux store
      dispatch(updateCommentCount(blogId));
      
      // Clear success message after 3 seconds
      setTimeout(() => {
        setSubmitStatus(null);
      }, 3000);
    } catch (err) {
      console.error('Failed to post comment', err);
      setSubmitStatus('error');
      setError(err.response?.data?.error || 'Failed to post comment');
    } finally {
      setIsSubmitting(false);
    }
  };

  useEffect(() => {
    fetchComments();
  }, [fetchComments]); // ✅ Safe now

  return (
    <div style={{ marginTop: '20px' }}>
      <h3 style={{ marginBottom: '20px', color: '#333' }}>
        Comments ({allComments.length})
      </h3>

      {/* Comment Form */}
      {user ? (
        <form onSubmit={handleSubmit} style={{ marginBottom: '30px' }}>
          {/* Status Messages */}
          {submitStatus === 'success' && (
            <div style={{ 
              background: '#d4edda', 
              color: '#155724', 
              padding: '10px', 
              borderRadius: '4px', 
              marginBottom: '15px',
              border: '1px solid #c3e6cb'
            }}>
              ✅ Comment posted successfully!
            </div>
          )}
          
          {submitStatus === 'error' && (
            <div style={{ 
              background: '#f8d7da', 
              color: '#721c24', 
              padding: '10px', 
              borderRadius: '4px', 
              marginBottom: '15px',
              border: '1px solid #f5c6cb'
            }}>
              ❌ {error || 'Failed to post comment. Please try again.'}
            </div>
          )}

          <div style={{ marginBottom: '15px' }}>
            <label style={{ display: 'block', marginBottom: '8px', fontWeight: 'bold' }}>
              Add a comment:
            </label>
            <textarea
              rows="4"
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              placeholder="Share your thoughts about this blog..."
              required
              disabled={isSubmitting}
              style={{
                width: '100%',
                padding: '12px',
                borderRadius: '6px',
                border: '1px solid #ddd',
                fontSize: '14px',
                resize: 'vertical',
                fontFamily: 'inherit'
              }}
            />
          </div>
          
          <button 
            type="submit" 
            disabled={isSubmitting || !comment.trim()}
            style={{
              backgroundColor: isSubmitting ? '#6c757d' : '#007bff',
              color: 'white',
              border: 'none',
              padding: '10px 20px',
              borderRadius: '4px',
              cursor: isSubmitting || !comment.trim() ? 'not-allowed' : 'pointer',
              fontSize: '14px',
              fontWeight: 'bold'
            }}
          >
            {isSubmitting ? 'Posting...' : 'Post Comment'}
          </button>
        </form>
      ) : (
        <div style={{ 
          padding: '15px', 
          backgroundColor: '#f8f9fa', 
          borderRadius: '6px', 
          marginBottom: '30px',
          textAlign: 'center'
        }}>
          <p style={{ margin: '0', color: '#666' }}>
            Please <a href="/login" style={{ color: '#007bff' }}>log in</a> to post a comment.
          </p>
        </div>
      )}

      {/* Comments List */}
      {error && !submitStatus && (
        <div style={{ color: 'red', marginBottom: '15px' }}>
          {error}
          <button 
            onClick={fetchComments} 
            style={{ marginLeft: '10px', padding: '4px 8px' }}
          >
            Retry
          </button>
        </div>
      )}

      {isLoading ? (
        <p style={{ textAlign: 'center', color: '#666' }}>Loading comments...</p>
      ) : allComments.length > 0 ? (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '15px' }}>
          {allComments.map((c, index) => (
            <div 
              key={c.id || index} 
              style={{
                padding: '15px',
                backgroundColor: '#f8f9fa',
                borderRadius: '8px',
                border: '1px solid #e9ecef'
              }}
            >
              <div style={{ 
                display: 'flex', 
                justifyContent: 'space-between', 
                alignItems: 'center',
                marginBottom: '8px'
              }}>
                <strong style={{ color: '#495057' }}>
                  {c.user?.name || c.author || 'Anonymous'}
                </strong>
                <small style={{ color: '#6c757d' }}>
                  {c.createdAt ? new Date(c.createdAt).toLocaleDateString() : 'Just now'}
                </small>
              </div>
              <p style={{ 
                margin: '0', 
                lineHeight: '1.5',
                color: '#212529'
              }}>
                {c.content}
              </p>
            </div>
          ))}
        </div>
      ) : (
        <div style={{ 
          textAlign: 'center', 
          padding: '30px',
          color: '#666',
          backgroundColor: '#f8f9fa',
          borderRadius: '8px'
        }}>
          <p style={{ margin: '0' }}>No comments yet. Be the first to comment!</p>
        </div>
      )}
    </div>
  );
};

export default CommentSection;