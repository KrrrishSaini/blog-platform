import React, { useEffect } from 'react';
import { useDispatch } from 'react-redux';
import { restoreAuth } from '../features/auth/authSlice';

const AuthWrapper = ({ children }) => {
  const dispatch = useDispatch();

  useEffect(() => {
    // Restore authentication state from localStorage on app startup
    dispatch(restoreAuth());
  }, [dispatch]);

  return children;
};

export default AuthWrapper;