import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import api from '../../services/api';

// Like blog
export const likeBlog = createAsyncThunk('blogs/likeBlog', async (blogId, thunkAPI) => {
  try {
    const res = await api.post(`/blogs/${blogId}/like`);
    return res.data;
  } catch (err) {
    return thunkAPI.rejectWithValue(err.response?.data || err.message);
  }
});

// Unlike blog
export const unlikeBlog = createAsyncThunk('blogs/unlikeBlog', async (blogId, thunkAPI) => {
  try {
    const res = await api.post(`/blogs/${blogId}/unlike`);
    return res.data;
  } catch (err) {
    return thunkAPI.rejectWithValue(err.response?.data || err.message);
  }
});

// Bookmark blog
export const bookmarkBlog = createAsyncThunk('blogs/bookmark', async (id, thunkAPI) => {
  try {
    const res = await api.post(`/blogs/${id}/bookmark`);
    return { blogId: id, ...res.data };
  } catch (err) {
    return thunkAPI.rejectWithValue(err.response?.data || err.message);
  }
});

// Remove bookmark
export const removeBookmark = createAsyncThunk('blogs/removeBookmark', async (id, thunkAPI) => {
  try {
    const res = await api.delete(`/blogs/${id}/bookmark`);
    return { blogId: id, ...res.data };
  } catch (err) {
    return thunkAPI.rejectWithValue(err.response?.data || err.message);
  }
});

// Get bookmarked blogs
export const getBookmarkedBlogs = createAsyncThunk('blogs/getBookmarked', async (_, thunkAPI) => {
  try {
    const res = await api.get('/blogs/bookmarks');
    return res.data;
  } catch (err) {
    return thunkAPI.rejectWithValue(err.response?.data || err.message);
  }
});

// Check bookmark status
export const checkBookmarkStatus = createAsyncThunk('blogs/checkBookmarkStatus', async (id, thunkAPI) => {
  try {
    const res = await api.get(`/blogs/${id}/bookmark-status`);
    return { blogId: id, isBookmarked: res.data.isBookmarked };
  } catch (err) {
    return thunkAPI.rejectWithValue(err.response?.data || err.message);
  }
});

// Increment view count
export const incrementView = createAsyncThunk('blogs/incrementView', async (blogId, thunkAPI) => {
  try {
    const res = await api.put(`/blogs/${blogId}/view`);
    return res.data;
  } catch (err) {
    return thunkAPI.rejectWithValue(err.response?.data || err.message);
  }
});

// Update comment count
export const updateCommentCount = createAsyncThunk('blogs/updateCommentCount', async (blogId, thunkAPI) => {
  try {
    const res = await api.get(`/blogs/${blogId}/comments`);
    return { blogId, commentCount: res.data.length };
  } catch (err) {
    return thunkAPI.rejectWithValue(err.response?.data || err.message);
  }
});

// Get all blogs
export const getAllBlogs = createAsyncThunk('blogs/getAll', async (_, thunkAPI) => {
  try {
    const res = await api.get('/blogs');
    return res.data;
  } catch (err) {
    return thunkAPI.rejectWithValue(err.response?.data || err.message);
  }
});

// Get blogs for the logged-in user
export const getUserBlogs = createAsyncThunk('blogs/getUserBlogs', async (_, thunkAPI) => {
  try {
    const res = await api.get('/blogs/user');
    return res.data;
  } catch (err) {
    return thunkAPI.rejectWithValue(err.response?.data || err.message);
  }
});

// Create a blog
export const createBlog = createAsyncThunk('blogs/create', async (data, thunkAPI) => {
  try {
    const res = await api.post('/blogs', data);
    return res.data;
  } catch (err) {
    return thunkAPI.rejectWithValue(err.response?.data || err.message);
  }
});

// Delete blog
export const deleteBlog = createAsyncThunk('blogs/delete', async (id, thunkAPI) => {
  try {
    await api.delete(`/blogs/${id}`);
    return id;
  } catch (err) {
    return thunkAPI.rejectWithValue(err.response?.data || err.message);
  }
});

// Update blog
export const updateBlog = createAsyncThunk('blogs/update', async ({ id, data }, thunkAPI) => {
  try {
    const res = await api.put(`/blogs/${id}`, data);
    return { id, data: res.data };
  } catch (err) {
    return thunkAPI.rejectWithValue(err.response?.data || err.message);
  }
});

const blogSlice = createSlice({
  name: 'blogs',
  initialState: {
    blogs: [], // All blogs (for All Blogs page)
    userBlogs: [], // User's own blogs (for Dashboard)
    bookmarkedBlogs: [], // User's bookmarked blogs
    bookmarkStatuses: {}, // Track bookmark status for each blog
    loading: false,
    error: null,
  },
  extraReducers: (builder) => {
    builder
      .addCase(getAllBlogs.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(getAllBlogs.fulfilled, (state, action) => {
        state.loading = false;
        state.blogs = action.payload;
      })
      .addCase(getAllBlogs.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.error || 'Something went wrong';
      })

      .addCase(getUserBlogs.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(getUserBlogs.fulfilled, (state, action) => {
        state.loading = false;
        state.userBlogs = action.payload;
      })
      .addCase(getUserBlogs.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.error || 'Failed to load user blogs';
      })

      .addCase(createBlog.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(createBlog.fulfilled, (state, action) => {
        state.loading = false;
        state.blogs.unshift(action.payload); // Add to all blogs
        state.userBlogs.unshift(action.payload); // Add to user blogs
      })
      .addCase(createBlog.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.error || 'Failed to create blog';
      })

      .addCase(deleteBlog.fulfilled, (state, action) => {
        state.blogs = state.blogs.filter(blog => blog.id !== action.payload);
        state.userBlogs = state.userBlogs.filter(blog => blog.id !== action.payload);
      })

      .addCase(updateBlog.fulfilled, (state, action) => {
        const updatedBlog = { ...action.payload.data, id: action.payload.id };
        
        // Update in all blogs
        const allBlogsIndex = state.blogs.findIndex(blog => blog.id === action.payload.id);
        if (allBlogsIndex !== -1) {
          state.blogs[allBlogsIndex] = { ...state.blogs[allBlogsIndex], ...action.payload.data };
        }
        
        // Update in user blogs
        const userBlogsIndex = state.userBlogs.findIndex(blog => blog.id === action.payload.id);
        if (userBlogsIndex !== -1) {
          state.userBlogs[userBlogsIndex] = { ...state.userBlogs[userBlogsIndex], ...action.payload.data };
        }
      })

      .addCase(likeBlog.fulfilled, (state, action) => {
        const updatedBlog = action.payload;
        
        // Update in all blogs
        const allBlogsIndex = state.blogs.findIndex(blog => blog.id === updatedBlog.id);
        if (allBlogsIndex !== -1) {
          state.blogs[allBlogsIndex] = updatedBlog;
        }
        
        // Update in user blogs
        const userBlogsIndex = state.userBlogs.findIndex(blog => blog.id === updatedBlog.id);
        if (userBlogsIndex !== -1) {
          state.userBlogs[userBlogsIndex] = updatedBlog;
        }
      })

      .addCase(unlikeBlog.fulfilled, (state, action) => {
        const updatedBlog = action.payload;
        
        // Update in all blogs
        const allBlogsIndex = state.blogs.findIndex(blog => blog.id === updatedBlog.id);
        if (allBlogsIndex !== -1) {
          state.blogs[allBlogsIndex] = updatedBlog;
        }
        
        // Update in user blogs
        const userBlogsIndex = state.userBlogs.findIndex(blog => blog.id === updatedBlog.id);
        if (userBlogsIndex !== -1) {
          state.userBlogs[userBlogsIndex] = updatedBlog;
        }
      })

      .addCase(incrementView.fulfilled, (state, action) => {
        const updatedBlog = action.payload;
        
        // Update in all blogs
        const allBlogsIndex = state.blogs.findIndex(blog => blog.id === updatedBlog.id);
        if (allBlogsIndex !== -1) {
          state.blogs[allBlogsIndex] = updatedBlog;
        }
        
        // Update in user blogs
        const userBlogsIndex = state.userBlogs.findIndex(blog => blog.id === updatedBlog.id);
        if (userBlogsIndex !== -1) {
          state.userBlogs[userBlogsIndex] = updatedBlog;
        }
      })

      .addCase(updateCommentCount.fulfilled, (state, action) => {
        const { blogId, commentCount } = action.payload;
        
        // Update in all blogs
        const allBlogsIndex = state.blogs.findIndex(blog => blog.id === blogId);
        if (allBlogsIndex !== -1) {
          state.blogs[allBlogsIndex] = {
            ...state.blogs[allBlogsIndex],
            commentCount: commentCount,
            comments: new Array(commentCount).fill(null) // Create array with correct length for backward compatibility
          };
        }
        
        // Update in user blogs
        const userBlogsIndex = state.userBlogs.findIndex(blog => blog.id === blogId);
        if (userBlogsIndex !== -1) {
          state.userBlogs[userBlogsIndex] = {
            ...state.userBlogs[userBlogsIndex],
            commentCount: commentCount,
            comments: new Array(commentCount).fill(null) // Create array with correct length for backward compatibility
          };
        }
      })

      // Bookmark reducers
      .addCase(bookmarkBlog.fulfilled, (state, action) => {
        const { blogId } = action.payload;
        state.bookmarkStatuses[blogId] = true;
      })

      .addCase(removeBookmark.fulfilled, (state, action) => {
        const { blogId } = action.payload;
        state.bookmarkStatuses[blogId] = false;
        // Remove from bookmarked blogs array
        state.bookmarkedBlogs = state.bookmarkedBlogs.filter(blog => blog.id !== blogId);
      })

      .addCase(getBookmarkedBlogs.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(getBookmarkedBlogs.fulfilled, (state, action) => {
        state.loading = false;
        state.bookmarkedBlogs = action.payload;
        // Update bookmark statuses
        action.payload.forEach(blog => {
          state.bookmarkStatuses[blog.id] = true;
        });
      })
      .addCase(getBookmarkedBlogs.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.error || 'Failed to fetch bookmarked blogs';
      })

      .addCase(checkBookmarkStatus.fulfilled, (state, action) => {
        const { blogId, isBookmarked } = action.payload;
        state.bookmarkStatuses[blogId] = isBookmarked;
      });
  },
});

export default blogSlice.reducer;