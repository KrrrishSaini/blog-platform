import React, { useEffect, useState, useCallback } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Link } from 'react-router-dom';
import { getUserBlogs } from '../features/blogs/blogSlice';
import { restoreAuth } from '../features/auth/authSlice';
import BlogCard from '../components/BlogCard';
import './Dashboard.scss';

const Dashboard = () => {
  const dispatch = useDispatch();
  const { userBlogs, loading, error } = useSelector(state => state.blogs);
  const { user } = useSelector(state => state.auth);
  const [refreshing, setRefreshing] = useState(false);

  // Get userId from user object
  const userId = user?.id;

  // Function to refresh blogs
  const refreshBlogs = useCallback(async () => {
    if (userId) {
      setRefreshing(true);
      try {
        await dispatch(getUserBlogs()).unwrap();
      } catch (error) {
        console.error('Failed to refresh blogs:', error);
      } finally {
        setRefreshing(false);
      }
    }
  }, [dispatch, userId]);

  useEffect(() => {
    // Restore auth state from localStorage if needed
    if (!user) {
      dispatch(restoreAuth());
    }
  }, [dispatch, user]);

  useEffect(() => {
    // Fetch blogs when userId is available
    if (userId) {
      dispatch(getUserBlogs());
    }
  }, [dispatch, userId]);

  // Show login message if user is not authenticated
  if (!user) {
    return (
      <div>
        <h2>Dashboard</h2>
        <p>Please log in to view your blogs.</p>
      </div>
    );
  }

  // Calculate stats
  const totalBlogs = userBlogs.length;
  const totalLikes = userBlogs.reduce((sum, blog) => sum + (blog.likes?.length || 0), 0);
  const totalViews = userBlogs.reduce((sum, blog) => sum + (blog.views || 0), 0);
  const totalComments = userBlogs.reduce((sum, blog) => sum + (blog.comments?.length || 0), 0);

  return (
    <div className="dashboard-page">
      <div className="dashboard-container">
        <div className="dashboard-header">
          <div className="welcome-section">
            <div className="user-avatar">👤</div>
            <h1>Welcome back, {user.name || user.email}!</h1>
            <p className="welcome-text">
              Ready to share your thoughts with the world? Your dashboard is your creative space.
            </p>
          </div>

          <div className="dashboard-stats">
            <div className="stat-card">
              <span className="stat-icon">📝</span>
              <span className="stat-number">{totalBlogs}</span>
              <span className="stat-label">Stories Published</span>
            </div>
            <div className="stat-card">
              <span className="stat-icon">❤️</span>
              <span className="stat-number">{totalLikes}</span>
              <span className="stat-label">Total Likes</span>
            </div>
            <div className="stat-card">
              <span className="stat-icon">👁️</span>
              <span className="stat-number">{totalViews}</span>
              <span className="stat-label">Total Views</span>
            </div>
            <div className="stat-card">
              <span className="stat-icon">💬</span>
              <span className="stat-number">{totalComments}</span>
              <span className="stat-label">Comments</span>
            </div>
          </div>

          <div className="dashboard-actions">
            <Link to="/create" className="action-btn primary">
              <span>✨</span>
              Write New Story
            </Link>
            <Link to="/blogs" className="action-btn secondary">
              <span>🌍</span>
              Explore Community
            </Link>
          </div>
        </div>

        <div className="blogs-section">
          <div className="section-header">
            <div className="section-title">
              <div className="section-icon">📚</div>
              <h2>Your Stories</h2>
            </div>
            <div className="section-actions">
              <span className="blog-count">
                {totalBlogs} {totalBlogs === 1 ? 'story' : 'stories'}
              </span>
              <button 
                onClick={refreshBlogs} 
                disabled={refreshing || loading}
                className="refresh-btn"
              >
                {refreshing ? (
                  <>
                    <div className="loading-spinner"></div>
                    Refreshing...
                  </>
                ) : (
                  <>
                    <span>🔄</span>
                    Refresh
                  </>
                )}
              </button>
            </div>
          </div>
          
          {error && (
            <div className="error-state">
              <div className="error-icon">⚠️</div>
              <h3>Oops! Something went wrong</h3>
              <p>
                {typeof error === 'string' ? error : error.message || 'Failed to load your blogs'}
              </p>
              <button onClick={refreshBlogs} className="retry-btn">
                Try Again
              </button>
            </div>
          )}
          
          {loading && !refreshing ? (
            <div className="loading-state">
              <div className="loading-spinner"></div>
              <p>Loading your amazing stories...</p>
            </div>
          ) : (
            userBlogs.length > 0 ? (
              <div className="blogs-grid">
                {userBlogs.map((blog, index) => (
                  <div key={blog.id} className="blog-item">
                    <BlogCard blog={blog} />
                  </div>
                ))}
              </div>
            ) : (
              <div className="empty-state">
                <div className="empty-icon">📝</div>
                <h3>Your Story Starts Here</h3>
                <p>
                  You haven't written any stories yet. Every great writer started with a single word. 
                  What story will you tell first?
                </p>
                <Link to="/create" className="create-first-btn">
                  <span>✨</span>
                  Write Your First Story
                </Link>
              </div>
            )
          )}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;