import React, { useEffect, useState, useCallback } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Link } from 'react-router-dom';
import { getAllBlogs } from '../features/blogs/blogSlice';
import BlogCard from '../components/BlogCard';

const AllBlogs = () => {
  const dispatch = useDispatch();
  const { blogs, loading, error } = useSelector(state => state.blogs);
  const { user } = useSelector(state => state.auth);
  const [refreshing, setRefreshing] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  // Function to refresh blogs
  const refreshBlogs = useCallback(async () => {
    setRefreshing(true);
    try {
      await dispatch(getAllBlogs()).unwrap();
    } catch (error) {
      console.error('Failed to refresh blogs:', error);
    } finally {
      setRefreshing(false);
    }
  }, [dispatch]);

  useEffect(() => {
    // Fetch all blogs when component mounts
    dispatch(getAllBlogs());
  }, [dispatch]);

  // Filter blogs based on search term
  const filteredBlogs = blogs.filter(blog =>
    blog.title?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    blog.content?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    blog.author?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (blog.tags && blog.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase())))
  );

  // Sort blogs by creation date (newest first)
  const sortedBlogs = [...filteredBlogs].sort((a, b) => 
    new Date(b.createdAt) - new Date(a.createdAt)
  );

  return (
    <div className="page-container">
      <div className="container">
        <div className="page-header">
          <h1>All Blogs</h1>
          <p>Discover amazing content from our community of writers</p>
        </div>

        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
            <span style={{ color: '#6b7280', fontSize: '0.875rem' }}>
              {sortedBlogs.length} blog{sortedBlogs.length !== 1 ? 's' : ''} found
            </span>
          </div>
          <button 
            onClick={refreshBlogs} 
            disabled={refreshing || loading}
            className={`btn btn-success btn-sm ${refreshing || loading ? '' : ''}`}
          >
            {refreshing ? (
              <>
                <div className="loading-spinner"></div>
                Refreshing...
              </>
            ) : (
              <>
                <span>🔄</span>
                Refresh
              </>
            )}
          </button>
        </div>

        {/* Search Bar */}
        <div className="form-group">
          <label htmlFor="search">Search Blogs</label>
          <input
            id="search"
            type="text"
            placeholder="Search blogs by title, content, author, or tags..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      
        {error && (
          <div className="alert alert-error">
            <strong>Error loading blogs:</strong><br/>
            {typeof error === 'string' ? error : JSON.stringify(error, null, 2)}
            <button 
              onClick={refreshBlogs} 
              className="btn btn-sm btn-secondary"
              style={{ marginLeft: '10px' }}
            >
              Retry
            </button>
          </div>
        )}

        {loading && !refreshing ? (
          <div style={{ textAlign: 'center', padding: '3rem' }}>
            <div className="loading-spinner" style={{ width: '40px', height: '40px', margin: '0 auto 1rem' }}></div>
            <p style={{ color: '#6b7280' }}>Loading amazing blogs...</p>
          </div>
        ) : (
          sortedBlogs.length > 0 ? (
            <div className="animate-fade-in">
              {sortedBlogs.map((blog, index) => (
                <div key={blog.id} style={{ animationDelay: `${index * 0.1}s` }}>
                  <BlogCard blog={blog} showAllBlogsView={true} />
                </div>
              ))}
            </div>
          ) : (
            <div style={{ 
              textAlign: 'center', 
              padding: '4rem 2rem',
              background: 'rgba(255, 255, 255, 0.5)',
              borderRadius: '1rem',
              backdropFilter: 'blur(10px)'
            }}>
              <div style={{ fontSize: '4rem', marginBottom: '1rem' }}>
                {searchTerm ? '🔍' : '📝'}
              </div>
              <h3 style={{ color: '#374151', marginBottom: '0.5rem' }}>
                {searchTerm ? 'No blogs found' : 'No blogs yet'}
              </h3>
             <p style={{ color: '#6b7280', marginBottom: '2rem' }}>
                {searchTerm 
                  ? 'Try adjusting your search terms or browse all blogs.' 
                  : 'Be the first to share your thoughts with the community!'
                }
               </p>
              {!searchTerm && user && (
                <Link to="/create" className="btn btn-primary">
                  <span>✨</span>
                  Create First Blog
                </Link>
              )}
              {!user && (
                <Link to="/login" className="btn btn-primary">
                  <span>🚀</span>
                  Login to Create Blogs
                </Link>
              )}
            </div>
          )
        )}
      </div>
    </div>
  );
};

export default AllBlogs;