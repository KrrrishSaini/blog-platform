import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { getBookmarkedBlogs } from '../features/blogs/blogSlice';
import BlogCard from '../components/BlogCard';
import { Link } from 'react-router-dom';
import './Bookmarks.scss';

const Bookmarks = () => {
  const dispatch = useDispatch();
  const { bookmarkedBlogs, loading, error } = useSelector((state) => state.blogs);
  const { user } = useSelector((state) => state.auth);

  useEffect(() => {
    if (user) {
      dispatch(getBookmarkedBlogs());
    }
  }, [dispatch, user]);

  if (!user) {
    return (
      <div className="bookmarks-page">
        <div className="bookmarks-container">
          <div className="auth-required">
            <div className="auth-icon">🔐</div>
            <h2>Login Required</h2>
            <p>Please log in to view your bookmarked blogs.</p>
            <Link to="/login" className="auth-btn">
              Login
            </Link>
          </div>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="bookmarks-page">
        <div className="bookmarks-container">
          <div className="loading-state">
            <div className="loading-spinner"></div>
            <p>Loading your bookmarked blogs...</p>
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bookmarks-page">
        <div className="bookmarks-container">
          <div className="error-state">
            <div className="error-icon">❌</div>
            <h2>Error Loading Bookmarks</h2>
            <p>{error}</p>
            <button 
              onClick={() => dispatch(getBookmarkedBlogs())}
              className="retry-btn"
            >
              Try Again
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bookmarks-page">
      <div className="bookmarks-container">
        <div className="bookmarks-header">
          <div className="header-icon">🔖</div>
          <h1>My Bookmarks</h1>
          <p>Your saved blogs for later reading</p>
        </div>

        {bookmarkedBlogs.length === 0 ? (
          <div className="empty-state">
            <div className="empty-icon">📑</div>
            <h2>No Bookmarks Yet</h2>
            <p>Start bookmarking blogs you want to read later!</p>
            <Link to="/blogs" className="browse-btn">
              <span>📚</span>
              Browse All Blogs
            </Link>
          </div>
        ) : (
          <div className="bookmarks-grid">
            {bookmarkedBlogs.map((blog) => (
              <BlogCard 
                key={blog.id} 
                blog={blog} 
                showAllBlogsView={true}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default Bookmarks;