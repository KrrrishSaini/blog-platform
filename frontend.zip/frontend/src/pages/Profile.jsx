import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Link } from 'react-router-dom';
import { updateProfile, getUserProfile } from '../features/auth/authSlice';
import './Profile.scss';

const Profile = () => {
  const dispatch = useDispatch();
  const { user, loading, error } = useSelector(state => state.auth);
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    bio: '',
    profilePicture: ''
  });
  const [previewImage, setPreviewImage] = useState('');
  const [updateSuccess, setUpdateSuccess] = useState(false);

  useEffect(() => {
    if (user) {
      setFormData({
        name: user.name || '',
        email: user.email || '',
        bio: user.bio || '',
        profilePicture: user.profilePicture || ''
      });
      setPreviewImage(user.profilePicture || '');
    }
  }, [user]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      // For now, we'll use a simple file reader to create a preview
      // In a real app, you'd upload to a cloud service like Firebase Storage
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviewImage(reader.result);
        setFormData(prev => ({
          ...prev,
          profilePicture: reader.result
        }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await dispatch(updateProfile(formData)).unwrap();
      setIsEditing(false);
      setUpdateSuccess(true);
      setTimeout(() => setUpdateSuccess(false), 3000);
    } catch (error) {
      console.error('Failed to update profile:', error);
    }
  };

  const handleCancel = () => {
    setIsEditing(false);
    // Reset form data to original user data
    if (user) {
      setFormData({
        name: user.name || '',
        email: user.email || '',
        bio: user.bio || '',
        profilePicture: user.profilePicture || ''
      });
      setPreviewImage(user.profilePicture || '');
    }
  };

  if (!user) {
    return (
      <div className="profile-page">
        <div className="profile-container">
          <div className="not-logged-in">
            <div className="login-icon">🔐</div>
            <h2>Access Your Profile</h2>
            <p>Please log in to view and manage your profile information.</p>
            <Link to="/login" className="login-btn">
              <span>🚀</span>
              Sign In Now
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="profile-page">
      <div className="profile-container">
        <div className="profile-header">
          <div className="header-icon">👤</div>
          <h1>My Profile</h1>
          <p>
            Manage your personal information and customize your blogging experience.
          </p>
        </div>

        <div className="profile-card">
          <div className="profile-card-header">
            <h2>
              <div className="title-icon">⚙️</div>
              Profile Settings
            </h2>
            {!isEditing && (
              <button
                onClick={() => setIsEditing(true)}
                className="edit-btn"
              >
                <span>✏️</span>
                Edit Profile
              </button>
            )}
          </div>

          {updateSuccess && (
            <div className="success-message">
              🎉 Profile updated successfully! Your changes have been saved.
            </div>
          )}

          {error && (
            <div className="error-message">
              ⚠️ {typeof error === 'string' ? error : error.message || 'Failed to update profile'}
            </div>
          )}

          <form onSubmit={handleSubmit} className="profile-form">
            {/* Profile Picture Section */}
            <div className="profile-avatar-section">
              <div className="avatar-container">
                <div className="avatar">
                  {previewImage ? (
                    <img src={previewImage} alt="Profile" />
                  ) : (
                    <span className="avatar-placeholder">👤</span>
                  )}
                </div>
                {isEditing && (
                  <label htmlFor="profilePicture" className="avatar-edit-overlay">
                    📷
                  </label>
                )}
              </div>
              
              {isEditing && (
                <div>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleImageChange}
                    className="hidden-file-input"
                    id="profilePicture"
                  />
                  <label htmlFor="profilePicture" className="change-photo-btn">
                    <span>📷</span>
                    Change Photo
                  </label>
                </div>
              )}
            </div>

            <div className="form-section">
              {/* Name Field */}
              <div className="form-group">
                <label className="form-label">
                  <span className="label-icon">👤</span>
                  Full Name
                </label>
                {isEditing ? (
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    placeholder="Enter your full name"
                    required
                    className="form-input"
                  />
                ) : (
                  <div className={`form-display ${!user.name ? 'empty' : ''}`}>
                    {user.name || 'Not provided'}
                  </div>
                )}
              </div>

              {/* Email Field */}
              <div className="form-group">
                <label className="form-label">
                  <span className="label-icon">📧</span>
                  Email Address
                </label>
                <div className="form-display">
                  {user.email}
                  <span className="email-note">(Email cannot be changed)</span>
                </div>
              </div>

              {/* Bio Field */}
              <div className="form-group">
                <label className="form-label">
                  <span className="label-icon">📝</span>
                  Bio
                </label>
                {isEditing ? (
                  <textarea
                    name="bio"
                    value={formData.bio}
                    onChange={handleInputChange}
                    placeholder="Tell us about yourself... Share your interests, writing style, or anything you'd like readers to know!"
                    className="form-textarea"
                  />
                ) : (
                  <div className={`form-display ${!user.bio ? 'empty' : ''}`}>
                    {user.bio || 'No bio provided yet. Add a bio to let readers know more about you!'}
                  </div>
                )}
              </div>
            </div>

            {/* Action Buttons */}
            {isEditing && (
              <div className="form-actions">
                <button
                  type="button"
                  onClick={handleCancel}
                  className="action-btn secondary"
                >
                  <span>❌</span>
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="action-btn primary"
                >
                  {loading ? (
                    <>
                      <div className="loading-spinner"></div>
                      Saving...
                    </>
                  ) : (
                    <>
                      <span>💾</span>
                      Save Changes
                    </>
                  )}
                </button>
              </div>
            )}
          </form>
        </div>
      </div>
    </div>
  );
};

export default Profile;