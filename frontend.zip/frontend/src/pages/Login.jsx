import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Link, useNavigate } from 'react-router-dom';
import { loginUser, logout } from '../features/auth/authSlice';
import './Login.scss';

const Login = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const { loading, error, user } = useSelector((state) => state.auth);

  const [formData, setFormData] = useState({
    email: '',
    password: '',
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    dispatch(loginUser(formData));
  };

  useEffect(() => {
    if (!loading && user) {
      alert('Login successful!');
      navigate('/dashboard'); // or any route you want after login
    }
  }, [loading, user, navigate]);

  // If user is already logged in, show a different message
  if (user && !loading) {
    return (
      <div className="login-page">
        <div className="login-container">
          <div className="login-card">
            <div className="login-header">
              <div className="login-icon">✅</div>
              <h1>Welcome Back!</h1>
              <p>You're already logged in as {user.name || user.email}</p>
            </div>
            
            <div style={{ display: 'flex', gap: '1rem', flexDirection: 'column' }}>
              <button 
                onClick={() => navigate('/dashboard')} 
                className="btn btn-primary btn-lg"
              >
                <span>🏠</span>
                Go to Dashboard
              </button>
              <button 
                onClick={() => {
                  dispatch(logout());
                  setFormData({ email: '', password: '' });
                }}
                className="btn btn-secondary btn-lg"
              >
                <span>🔄</span>
                Switch Account
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="login-page">
      <div className="login-container">
        <div className="login-card">
          <div className="login-header">
            <div className="login-icon">🔐</div>
            <h1>Welcome Back</h1>
            <p>Sign in to your account to continue</p>
          </div>

          {error && (
            <div className="error-message">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="login-form">
            <div className="form-group">
              <label htmlFor="email">Email Address</label>
              <input 
                id="email"
                name="email" 
                type="email" 
                placeholder="Enter your email" 
                onChange={handleChange} 
                value={formData.email} 
                required 
              />
            </div>

            <div className="form-group">
              <label htmlFor="password">Password</label>
              <input 
                id="password"
                name="password" 
                type="password" 
                placeholder="Enter your password" 
                onChange={handleChange} 
                value={formData.password} 
                required 
              />
            </div>

            <button type="submit" disabled={loading} className="login-button">
              {loading ? (
                <>
                  <div className="loading-spinner"></div>
                  Signing in...
                </>
              ) : (
                <>
                  <span>🚀</span>
                  Sign In
                </>
              )}
            </button>
          </form>

          <div className="login-footer">
            <p>Don't have an account?</p>
            <Link to="/register" className="register-link">
              Create your account here
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;