// src/pages/Register.jsx
import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Link, useNavigate } from 'react-router-dom';
import { registerUser, logout } from '../features/auth/authSlice';
import './Register.scss';

const Register = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();

  // ✅ include user in selector
  const { loading, error, user } = useSelector((state) => state.auth);

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    role: 'user',
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    dispatch(registerUser(formData));
  };

  useEffect(() => {
    if (!loading && user) {
      alert('Registration successful!');
      navigate('/dashboard');
    }
  }, [loading, user, navigate]);

  // If user is already logged in, show a different message
  if (user && !loading) {
    return (
      <div className="register-page">
        <div className="register-container">
          <div className="register-card">
            <div className="register-header">
              <div className="register-icon">✅</div>
              <h1>Welcome Back!</h1>
              <p>You're already logged in as {user.name || user.email}</p>
            </div>
            
            <div style={{ display: 'flex', gap: '1rem', flexDirection: 'column' }}>
              <button 
                onClick={() => navigate('/dashboard')} 
                className="btn btn-primary btn-lg"
              >
                <span>🏠</span>
                Go to Dashboard
              </button>
              <button 
                onClick={() => {
                  dispatch(logout());
                  setFormData({ name: '', email: '', password: '', role: 'user' });
                }}
                className="btn btn-secondary btn-lg"
              >
                <span>🔄</span>
                Register New Account
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="register-page">
      <div className="register-container">
        <div className="register-card">
          <div className="register-header">
            <div className="register-icon">🚀</div>
            <h1>Join Our Community</h1>
            <p>Create your account and start sharing your amazing stories</p>
          </div>

          {error && (
            <div className="error-message">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="register-form">
            <div className="form-row">
              <div className="form-group">
                <label htmlFor="name" className="form-label">Full Name</label>
                <div className="input-icon">
                  <span className="icon">👤</span>
                  <input 
                    id="name"
                    name="name" 
                    type="text"
                    placeholder="Enter your full name" 
                    onChange={handleChange} 
                    value={formData.name} 
                    className="form-input"
                    required 
                  />
                </div>
              </div>
            </div>

            <div className="form-row">
              <div className="form-group">
                <label htmlFor="email" className="form-label">Email Address</label>
                <div className="input-icon">
                  <span className="icon">📧</span>
                  <input 
                    id="email"
                    name="email" 
                    type="email" 
                    placeholder="Enter your email" 
                    onChange={handleChange} 
                    value={formData.email} 
                    className="form-input"
                    required 
                  />
                </div>
              </div>
            </div>

            <div className="form-row">
              <div className="form-group">
                <label htmlFor="password" className="form-label">Password</label>
                <div className="input-icon">
                  <span className="icon">🔒</span>
                  <input 
                    id="password"
                    name="password" 
                    type="password" 
                    placeholder="Create a strong password" 
                    onChange={handleChange} 
                    value={formData.password} 
                    className="form-input"
                    required 
                  />
                </div>
              </div>
            </div>

            <div className="form-row single-column">
              <div className="form-group role-selection">
                <label className="form-label">Choose Your Role</label>
                <div className="role-options">
                  <div className="role-option">
                    <input 
                      type="radio" 
                      id="role-user" 
                      name="role" 
                      value="user" 
                      checked={formData.role === 'user'}
                      onChange={handleChange}
                    />
                    <label htmlFor="role-user" className="role-card">
                      <span className="role-icon">✍️</span>
                      <div className="role-name">Writer</div>
                      <div className="role-desc">Share your stories and connect with readers</div>
                    </label>
                  </div>
                  <div className="role-option">
                    <input 
                      type="radio" 
                      id="role-admin" 
                      name="role" 
                      value="admin" 
                      checked={formData.role === 'admin'}
                      onChange={handleChange}
                    />
                    <label htmlFor="role-admin" className="role-card">
                      <span className="role-icon">👑</span>
                      <div className="role-name">Admin</div>
                      <div className="role-desc">Manage the platform and community</div>
                    </label>
                  </div>
                </div>
              </div>
            </div>

            <button type="submit" disabled={loading} className="register-button">
              {loading ? (
                <>
                  <div className="loading-spinner"></div>
                  Creating Account...
                </>
              ) : (
                <>
                  <span>🎯</span>
                  Create Account
                </>
              )}
            </button>
          </form>

          <div className="register-footer">
            <p>Already have an account?</p>
            <Link to="/login" className="login-link">
              Sign in here
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Register;