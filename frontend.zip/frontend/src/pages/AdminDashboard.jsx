import React, { useEffect, useState } from 'react';
import { fetchAdminStats } from '../services/api';

const AdminDashboard = () => {
  const [stats, setStats] = useState(null);
  const [error, setError] = useState('');
  const token = localStorage.getItem('token');

  useEffect(() => {
    const getStats = async () => {
      try {
        const data = await fetchAdminStats(token);
        setStats(data);
      } catch (err) {
        setError('Failed to load admin stats');
      }
    };
    getStats();
  }, [token]);

  if (error) return <p style={{ color: 'red' }}>{error}</p>;
  if (!stats) return <p>Loading stats...</p>;

  return (
    <div>
      <h2>Admin Dashboard</h2>
      <p><strong>Total Blogs:</strong> {stats.totalBlogs}</p>
      <p><strong>Total Views:</strong> {stats.totalViews}</p>
      <p><strong>Total Likes:</strong> {stats.totalLikes}</p>
    </div>
  );
};

export default AdminDashboard;