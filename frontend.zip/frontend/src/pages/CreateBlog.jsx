import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { createBlog, getUserBlogs } from '../features/blogs/blogSlice';
import { useNavigate, Link } from 'react-router-dom';
import './CreateBlog.scss';

// Helper function to convert file to base64
const convertToBase64 = (file) => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result);
    reader.onerror = (error) => reject(error);
  });
};

const CreateBlog = () => {
  const [formData, setFormData] = useState({ title: '', content: '', tags: '' });
  const [selectedImage, setSelectedImage] = useState(null);
  const [imagePreview, setImagePreview] = useState(null);
  const [successMessage, setSuccessMessage] = useState('');
  const { loading, error } = useSelector((state) => state.blogs);
  const { user } = useSelector((state) => state.auth);
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setSelectedImage(file);
      // Create preview URL
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const removeImage = () => {
    setSelectedImage(null);
    setImagePreview(null);
    // Reset file input
    const fileInput = document.getElementById('image');
    if (fileInput) fileInput.value = '';
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSuccessMessage('');
    
    if (!user) {
      navigate('/login');
      return;
    }

    try {
      console.log('Creating blog with data:', formData);
      console.log('User data:', user);
      
      // Process tags - split by comma and clean up
      const tagsArray = formData.tags 
        ? formData.tags.split(',').map(tag => tag.trim()).filter(tag => tag.length > 0)
        : [];

      // Convert image to base64 if selected
      let imageBase64 = null;
      if (selectedImage) {
        imageBase64 = await convertToBase64(selectedImage);
      }

      // Create blog data object
      const blogData = {
        title: formData.title,
        content: formData.content,
        tags: tagsArray,
        imageBase64: imageBase64
      };

      const result = await dispatch(createBlog(blogData));

      console.log('CreateBlog result:', result);

      if (result.type === 'blogs/create/fulfilled') {
        setFormData({ title: '', content: '', tags: '' });
        setSelectedImage(null);
        setImagePreview(null);
        setSuccessMessage('🎉 Blog created successfully! Redirecting to your dashboard...');
        dispatch(getUserBlogs()); // Refresh the user's blogs
        
        // Redirect after showing success message
        setTimeout(() => {
          navigate('/dashboard');
        }, 2000);
      } else if (result.type === 'blogs/create/rejected') {
        console.error('Blog creation failed:', result.payload);
      }
    } catch (err) {
      console.error('Error creating blog:', err);
    }
  };

  // Character count helpers
  const titleLength = formData.title.length;
  const contentLength = formData.content.length;
  const titleMaxLength = 100;
  const contentMaxLength = 10000;

  return (
    <div className="create-blog-page">
      <div className="create-blog-container">
        <div className="create-blog-header">
          <div className="header-icon">✍️</div>
          <h1>Create Your Story</h1>
          <p>
            Share your thoughts, experiences, and insights with the world. 
            Every great story starts with a single word.
          </p>
        </div>

        {successMessage && (
          <div className="success-message">
            {successMessage}
          </div>
        )}

        {error && (
          <div className="error-message">
            {typeof error === 'string' ? error : 'An error occurred while creating your blog. Please try again.'}
          </div>
        )}

        <form onSubmit={handleSubmit} className="create-blog-form">
          <div className="form-section">
            <div className="section-header">
              <div className="section-icon">📝</div>
              <h3>Blog Title</h3>
            </div>
            
            <div className="form-group">
              <label htmlFor="title">Give your story a compelling title</label>
              <input
                id="title"
                name="title"
                type="text"
                placeholder="Enter an engaging title that captures your story..."
                onChange={handleChange}
                value={formData.title}
                maxLength={titleMaxLength}
                required
              />
              <div className={`char-counter ${titleLength > titleMaxLength * 0.9 ? 'warning' : ''} ${titleLength >= titleMaxLength ? 'error' : ''}`}>
                {titleLength}/{titleMaxLength} characters
              </div>
            </div>

            <div className="writing-tips">
              <div className="tips-header">
                <span className="tips-icon">💡</span>
                <h4>Title Tips</h4>
              </div>
              <ul>
                <li>Keep it clear and descriptive</li>
                <li>Use action words when possible</li>
                <li>Make it intriguing but not clickbait</li>
                <li>Consider your target audience</li>
              </ul>
            </div>
          </div>

          <div className="form-section">
            <div className="section-header">
              <div className="section-icon">📖</div>
              <h3>Your Story</h3>
            </div>
            
            <div className="form-group">
              <label htmlFor="content">Write your story</label>
              <textarea
                id="content"
                name="content"
                placeholder="Start writing your story here... Share your thoughts, experiences, insights, or anything you're passionate about. Your unique perspective matters!"
                onChange={handleChange}
                value={formData.content}
                maxLength={contentMaxLength}
                required
              />
              <div className={`char-counter ${contentLength > contentMaxLength * 0.9 ? 'warning' : ''} ${contentLength >= contentMaxLength ? 'error' : ''}`}>
                {contentLength}/{contentMaxLength} characters
              </div>
            </div>

            <div className="writing-tips">
              <div className="tips-header">
                <span className="tips-icon">✨</span>
                <h4>Writing Tips</h4>
              </div>
              <ul>
                <li>Start with a hook to grab attention</li>
                <li>Use short paragraphs for better readability</li>
                <li>Include personal anecdotes or examples</li>
                <li>End with a thought-provoking conclusion</li>
                <li>Proofread before publishing</li>
              </ul>
            </div>
          </div>

          <div className="form-section">
            <div className="section-header">
              <div className="section-icon">🏷️</div>
              <h3>Tags</h3>
            </div>
            
            <div className="form-group">
              <label htmlFor="tags">Add tags to help readers find your story</label>
              <input
                id="tags"
                name="tags"
                type="text"
                placeholder="e.g., technology, lifestyle, travel, programming (separate with commas)"
                onChange={handleChange}
                value={formData.tags}
              />
              <div className="tags-preview">
                {formData.tags && formData.tags.split(',').map(tag => tag.trim()).filter(tag => tag.length > 0).map((tag, index) => (
                  <span key={index} className="tag-preview">#{tag}</span>
                ))}
              </div>
            </div>

            <div className="writing-tips">
              <div className="tips-header">
                <span className="tips-icon">🏷️</span>
                <h4>Tagging Tips</h4>
              </div>
              <ul>
                <li>Use 3-5 relevant tags for best discoverability</li>
                <li>Choose specific tags over generic ones</li>
                <li>Include both topic and category tags</li>
                <li>Separate tags with commas</li>
              </ul>
            </div>
          </div>

          <div className="form-section">
            <div className="section-header">
              <div className="section-icon">🖼️</div>
              <h3>Featured Image</h3>
            </div>
            
            <div className="form-group">
              <label htmlFor="image">Add a featured image to your story (optional)</label>
              <input
                id="image"
                name="image"
                type="file"
                accept="image/*"
                onChange={handleImageChange}
                className="file-input"
              />
              
              {imagePreview && (
                <div className="image-preview">
                  <img src={imagePreview} alt="Preview" />
                  <button type="button" onClick={removeImage} className="remove-image-btn">
                    ✕ Remove Image
                  </button>
                </div>
              )}
            </div>

            <div className="writing-tips">
              <div className="tips-header">
                <span className="tips-icon">🖼️</span>
                <h4>Image Tips</h4>
              </div>
              <ul>
                <li>Use high-quality images (max 5MB)</li>
                <li>Choose images that complement your story</li>
                <li>Ensure you have rights to use the image</li>
                <li>Consider the image's visual impact</li>
              </ul>
            </div>
          </div>

          <div className="form-actions">
            <Link to="/dashboard" className="action-btn secondary">
              <span>←</span>
              Cancel
            </Link>
            <button 
              type="submit" 
              disabled={loading || !formData.title.trim() || !formData.content.trim()}
              className="action-btn primary"
            >
              {loading ? (
                <>
                  <div className="loading-spinner"></div>
                  Publishing...
                </>
              ) : (
                <>
                  <span>🚀</span>
                  Publish Story
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default CreateBlog;