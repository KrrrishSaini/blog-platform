import React from 'react';
import { Link } from 'react-router-dom';
import { useSelector } from 'react-redux';
import './Home.scss';

const Home = () => {
  const { user } = useSelector((state) => state.auth);

  return (
    <div className="home-page">
      {/* Hero Section */}
      <section className="hero-section">
        <div className="hero-container">
          <h1 className="hero-title">
            Share Your Stories with the World
          </h1>
          <p className="hero-subtitle">
            Join our vibrant community of writers and readers. Create, discover, and engage with amazing content from passionate storytellers around the globe.
          </p>
          <div className="hero-actions">
            {user ? (
              <>
                <Link to="/create" className="hero-btn primary">
                  <span>✨</span>
                  Create Your First Blog
                </Link>
                <Link to="/blogs" className="hero-btn secondary">
                  <span>📚</span>
                  Explore Blogs
                </Link>
              </>
            ) : (
              <>
                <Link to="/register" className="hero-btn primary">
                  <span>🚀</span>
                  Get Started Free
                </Link>
                <Link to="/blogs" className="hero-btn secondary">
                  <span>📖</span>
                  Browse Stories
                </Link>
              </>
            )}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="features-section">
        <div className="features-container">
          <div className="features-header">
            <h2>Why Choose Our Platform?</h2>
            <p>
              Everything you need to create, share, and grow your audience in one beautiful, intuitive platform.
            </p>
          </div>
          
          <div className="features-grid">
            <div className="feature-card">
              <div className="feature-icon">✍️</div>
              <h3>Easy Writing</h3>
              <p>
                Intuitive editor with rich formatting options. Focus on your content while we handle the rest.
              </p>
            </div>
            
            <div className="feature-card">
              <div className="feature-icon">🌍</div>
              <h3>Global Reach</h3>
              <p>
                Share your stories with readers worldwide. Build your audience and connect with like-minded people.
              </p>
            </div>
            
            <div className="feature-card">
              <div className="feature-icon">💬</div>
              <h3>Engage & Connect</h3>
              <p>
                Like, comment, and interact with other writers. Build meaningful connections in our community.
              </p>
            </div>
            
            <div className="feature-card">
              <div className="feature-icon">📊</div>
              <h3>Track Performance</h3>
              <p>
                Monitor your blog's performance with detailed analytics. See what resonates with your audience.
              </p>
            </div>
            
            <div className="feature-card">
              <div className="feature-icon">🎨</div>
              <h3>Beautiful Design</h3>
              <p>
                Your content deserves to look amazing. Our platform ensures your blogs always look professional.
              </p>
            </div>
            
            <div className="feature-card">
              <div className="feature-icon">🔒</div>
              <h3>Secure & Reliable</h3>
              <p>
                Your content is safe with us. Enterprise-grade security and reliable hosting you can trust.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="stats-section">
        <div className="stats-container">
          <div className="stats-grid">
            <div className="stat-item">
              <span className="stat-number">10K+</span>
              <span className="stat-label">Active Writers</span>
            </div>
            <div className="stat-item">
              <span className="stat-number">50K+</span>
              <span className="stat-label">Stories Published</span>
            </div>
            <div className="stat-item">
              <span className="stat-number">1M+</span>
              <span className="stat-label">Monthly Readers</span>
            </div>
            <div className="stat-item">
              <span className="stat-number">25K+</span>
              <span className="stat-label">Community Members</span>
            </div>
          </div>
        </div>
      </section>

      {/* Call to Action Section */}
      <section className="cta-section">
        <div className="cta-container">
          <h2>Ready to Start Your Journey?</h2>
          <p>
            Join thousands of writers who have already discovered the joy of sharing their stories. 
            Your voice matters, and your stories deserve to be heard.
          </p>
          <div className="cta-actions">
            {user ? (
              <>
                <Link to="/create" className="cta-btn primary">
                  <span>✨</span>
                  Write Your First Story
                </Link>
                <Link to="/dashboard" className="cta-btn secondary">
                  <span>📊</span>
                  Go to Dashboard
                </Link>
              </>
            ) : (
              <>
                <Link to="/register" className="cta-btn primary">
                  <span>🎯</span>
                  Start Writing Today
                </Link>
                <Link to="/login" className="cta-btn secondary">
                  <span>👋</span>
                  Sign In
                </Link>
              </>
            )}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;