import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useParams, useNavigate } from 'react-router-dom';
import { getAllBlogs, likeBlog, unlikeBlog, incrementView, bookmarkBlog, removeBookmark, checkBookmarkStatus } from '../features/blogs/blogSlice';
import CommentSection from '../components/CommentSection';

const BlogDetails = () => {
  const { id } = useParams();
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { blogs, loading, bookmarkStatuses } = useSelector((state) => state.blogs);
  const { user } = useSelector((state) => state.auth);
  const [isLiking, setIsLiking] = useState(false);
  const [isBookmarking, setIsBookmarking] = useState(false);
  const [viewIncremented, setViewIncremented] = useState(false);
  
  const blog = blogs.find((b) => b.id === id);

  useEffect(() => {
    if (!blog) {
      dispatch(getAllBlogs());
    }
  }, [dispatch, blog]);

  useEffect(() => {
    // Increment view count when blog is loaded and not already incremented
    if (blog && !viewIncremented) {
      dispatch(incrementView(id));
      setViewIncremented(true);
    }
  }, [dispatch, id, blog, viewIncremented]);

  // Check bookmark status when blog is loaded and user is authenticated
  useEffect(() => {
    if (blog && user && bookmarkStatuses[id] === undefined) {
      dispatch(checkBookmarkStatus(id));
    }
  }, [dispatch, blog, user, id, bookmarkStatuses]);

  const handleLikeToggle = async () => {
    if (!user) {
      alert('Please log in to like blogs');
      return;
    }

    setIsLiking(true);
    try {
      if (hasLiked) {
        await dispatch(unlikeBlog(id)).unwrap();
      } else {
        await dispatch(likeBlog(id)).unwrap();
      }
    } catch (error) {
      console.error('Failed to toggle like:', error);
      alert('Failed to update like. Please try again.');
    } finally {
      setIsLiking(false);
    }
  };

  const handleBookmarkToggle = async () => {
    if (!user) {
      alert('Please log in to bookmark blogs');
      return;
    }

    setIsBookmarking(true);
    try {
      const isBookmarked = bookmarkStatuses[id] || false;
      if (isBookmarked) {
        await dispatch(removeBookmark(id));
      } else {
        await dispatch(bookmarkBlog(id));
      }
    } catch (error) {
      console.error('Error toggling bookmark:', error);
    } finally {
      setIsBookmarking(false);
    }
  };

  const hasLiked = blog?.likes?.includes(user?.id);
  const isBookmarked = bookmarkStatuses[id] || false;

  if (!blog && loading) return <div style={{ padding: '20px' }}>Loading...</div>;
  if (!blog) return <div style={{ padding: '20px' }}>Blog not found.</div>;

  return (
    <div style={{ padding: '20px', maxWidth: '800px', margin: '0 auto' }}>
      <button 
        onClick={() => navigate(-1)}
        style={{
          marginBottom: '20px',
          padding: '8px 16px',
          backgroundColor: '#6c757d',
          color: 'white',
          border: 'none',
          borderRadius: '4px',
          cursor: 'pointer'
        }}
      >
        ← Back
      </button>

      <article style={{
        backgroundColor: '#fff',
        padding: '30px',
        borderRadius: '8px',
        boxShadow: '0 2px 10px rgba(0,0,0,0.1)',
        marginBottom: '30px'
      }}>
        <h1 style={{ marginTop: '0', color: '#333', fontSize: '2.5rem' }}>{blog.title}</h1>
        
        <div style={{ 
          marginBottom: '20px', 
          padding: '15px 0',
          borderBottom: '1px solid #eee',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          flexWrap: 'wrap',
          gap: '10px'
        }}>
          <div style={{ display: 'flex', gap: '20px', alignItems: 'center' }}>
            <span style={{ color: '#666' }}>
              <strong>By:</strong> {blog.author || 'Unknown'}
            </span>
            <span style={{ color: '#666' }}>
              <strong>Posted:</strong> {new Date(blog.createdAt).toLocaleDateString()}
            </span>
          </div>
          
          <div style={{ display: 'flex', gap: '15px', alignItems: 'center' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
              <span>👍 {blog.likes?.length || 0}</span>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
              <span>👁️ {blog.views || 0}</span>
            </div>
          </div>
        </div>

        {blog.imageBase64 && (
          <div style={{ 
            width: '100%', 
            position: 'relative',
            borderRadius: '8px', 
            marginBottom: '25px',
            boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)'
          }}>
            <div style={{ 
              maxHeight: '400px', 
              overflow: 'hidden', 
              borderRadius: '8px',
            }}>
              <img 
                src={blog.imageBase64} 
                alt={blog.title}
                style={{
                  width: '100%',
                  height: 'auto',
                  objectFit: 'cover'
                }}
                onClick={() => {
                  // Create a modal to show the full image
                  const modal = document.createElement('div');
                  modal.style.position = 'fixed';
                  modal.style.top = '0';
                  modal.style.left = '0';
                  modal.style.width = '100%';
                  modal.style.height = '100%';
                  modal.style.backgroundColor = 'rgba(0,0,0,0.9)';
                  modal.style.display = 'flex';
                  modal.style.justifyContent = 'center';
                  modal.style.alignItems = 'center';
                  modal.style.zIndex = '1000';
                  modal.style.padding = '20px';
                  modal.style.cursor = 'pointer';
                  
                  const img = document.createElement('img');
                  img.src = blog.imageBase64;
                  img.style.maxWidth = '90%';
                  img.style.maxHeight = '90%';
                  img.style.objectFit = 'contain';
                  img.style.borderRadius = '4px';
                  
                  modal.appendChild(img);
                  document.body.appendChild(modal);
                  
                  modal.onclick = () => {
                    document.body.removeChild(modal);
                  };
                }}
              />
            </div>
            <button
              onClick={() => {
                // Create a modal to show the full image
                const modal = document.createElement('div');
                modal.style.position = 'fixed';
                modal.style.top = '0';
                modal.style.left = '0';
                modal.style.width = '100%';
                modal.style.height = '100%';
                modal.style.backgroundColor = 'rgba(0,0,0,0.9)';
                modal.style.display = 'flex';
                modal.style.justifyContent = 'center';
                modal.style.alignItems = 'center';
                modal.style.zIndex = '1000';
                modal.style.padding = '20px';
                modal.style.cursor = 'pointer';
                
                const img = document.createElement('img');
                img.src = blog.imageBase64;
                img.style.maxWidth = '90%';
                img.style.maxHeight = '90%';
                img.style.objectFit = 'contain';
                img.style.borderRadius = '4px';
                
                modal.appendChild(img);
                document.body.appendChild(modal);
                
                modal.onclick = () => {
                  document.body.removeChild(modal);
                };
              }}
              style={{
                position: 'absolute',
                bottom: '10px',
                right: '10px',
                backgroundColor: 'rgba(0,0,0,0.7)',
                color: 'white',
                border: 'none',
                borderRadius: '4px',
                padding: '8px 12px',
                cursor: 'pointer',
                fontSize: '14px',
                fontWeight: 'bold',
                display: 'flex',
                alignItems: 'center',
                gap: '5px'
              }}
            >
              <span style={{ fontSize: '16px' }}>🔍</span> View Full Image
            </button>
          </div>
        )}

        {blog.tags && blog.tags.length > 0 && (
          <div style={{ 
            display: 'flex', 
            flexWrap: 'wrap', 
            gap: '8px', 
            marginBottom: '25px' 
          }}>
            {blog.tags.map((tag, index) => (
              <span 
                key={index} 
                style={{
                  display: 'inline-flex',
                  alignItems: 'center',
                  padding: '4px 12px',
                  background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                  color: 'white',
                  borderRadius: '16px',
                  fontSize: '0.85rem',
                  fontWeight: '500',
                  boxShadow: '0 2px 4px rgba(102, 126, 234, 0.2)'
                }}
              >
                #{tag}
              </span>
            ))}
          </div>
        )}

        <div style={{ 
          lineHeight: '1.8', 
          fontSize: '1.1rem',
          color: '#444',
          marginBottom: '30px'
        }}>
          {blog.content.split('\n').map((paragraph, index) => (
            <p key={index} style={{ marginBottom: '15px' }}>
              {paragraph}
            </p>
          ))}
        </div>

        <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
          <button 
            onClick={handleLikeToggle}
            disabled={isLiking}
            style={{
              backgroundColor: hasLiked ? '#10b981' : 'white',
              color: hasLiked ? 'white' : '#374151',
              border: hasLiked ? '2px solid #10b981' : '2px solid #e5e7eb',
              padding: '12px 20px',
              borderRadius: '6px',
              cursor: isLiking ? 'not-allowed' : 'pointer',
              fontSize: '16px',
              opacity: isLiking ? 0.7 : 1,
              fontWeight: 'bold'
            }}
          >
            {isLiking ? 'Loading...' : (hasLiked ? '👍 Liked' : '👍 Like')}
          </button>

          <button 
            onClick={handleBookmarkToggle}
            disabled={isBookmarking}
            style={{
              backgroundColor: isBookmarked ? '#f59e0b' : 'white',
              color: isBookmarked ? 'white' : '#374151',
              border: isBookmarked ? '2px solid #f59e0b' : '2px solid #e5e7eb',
              padding: '12px 20px',
              borderRadius: '6px',
              cursor: isBookmarking ? 'not-allowed' : 'pointer',
              fontSize: '16px',
              opacity: isBookmarking ? 0.7 : 1,
              fontWeight: 'bold'
            }}
          >
            {isBookmarking ? 'Loading...' : (isBookmarked ? '🔖 Bookmarked' : '📑 Bookmark')}
          </button>

          {user && blog.userId === user.id && (
            <button 
              onClick={() => navigate(`/edit/${blog.id}`)}
              style={{
                backgroundColor: '#ffc107',
                color: '#212529',
                border: 'none',
                padding: '12px 20px',
                borderRadius: '6px',
                cursor: 'pointer',
                fontSize: '16px',
                fontWeight: 'bold'
              }}
            >
              ✏️ Edit Blog
            </button>
          )}
        </div>
      </article>

      <div style={{
        backgroundColor: '#fff',
        padding: '20px',
        borderRadius: '8px',
        boxShadow: '0 2px 10px rgba(0,0,0,0.1)'
      }}>
        <CommentSection blogId={id} />
      </div>
    </div>
  );
};

export default BlogDetails;